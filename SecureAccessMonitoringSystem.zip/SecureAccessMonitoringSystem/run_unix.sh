#!/bin/bash

echo "========================================"
echo " Defence Operations Monitoring System"
echo " Starting Application..."
echo "========================================"
echo ""

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    echo "ERROR: Maven is not installed or not in PATH"
    echo "Please install Maven from: https://maven.apache.org/download.cgi"
    exit 1
fi

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "ERROR: Java is not installed or not in PATH"
    echo "Please install JDK 17+ from: https://www.oracle.com/java/technologies/downloads/"
    exit 1
fi

echo "Step 1: Cleaning and compiling project..."
mvn clean compile

if [ $? -ne 0 ]; then
    echo ""
    echo "ERROR: Build failed! Check the error messages above."
    exit 1
fi

echo ""
echo "Step 2: Running application..."
echo ""
mvn exec:java -Dexec.mainClass="Main"
