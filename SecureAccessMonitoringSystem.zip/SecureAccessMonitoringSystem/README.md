# Defence Operations - Secure Access Monitoring System

## 🚀 How to Run the Project

### Prerequisites

1. **Java Development Kit (JDK) 17 or higher**
   - Download from: https://www.oracle.com/java/technologies/downloads/
   - Verify installation: `java -version`

2. **Apache Maven**
   - Download from: https://maven.apache.org/download.cgi
   - Verify installation: `mvn -version`

3. **IDE (Optional but Recommended)**
   - IntelliJ IDEA, Eclipse, or NetBeans

---

## 📋 Method 1: Using Maven Command Line

### Step 1: Navigate to Project Directory
```bash
cd SecureAccessMonitoringSystem
```

### Step 2: Clean and Compile the Project
```bash
mvn clean compile
```

### Step 3: Run the Application
```bash
mvn exec:java -Dexec.mainClass="Main"
```

**OR** Build and run the JAR:
```bash
mvn clean package
java -jar target/SecureAccessMonitoringSystem-1.0-SNAPSHOT.jar
```

---

## 🔧 Method 2: Using IntelliJ IDEA

### Step 1: Open Project
1. Open IntelliJ IDEA
2. Click `File` → `Open`
3. Select the `SecureAccessMonitoringSystem` folder
4. Wait for Maven to download dependencies

### Step 2: Configure JDK
1. Go to `File` → `Project Structure` → `Project`
2. Set SDK to Java 17 or higher
3. Click `Apply` and `OK`

### Step 3: Run the Application
1. Navigate to `src/main/java/Main.java`
2. Right-click on the file
3. Select `Run 'Main.main()'`

**OR** Click the green play button ▶️ next to the `main` method

---

## 🔧 Method 3: Using Eclipse

### Step 1: Import Project
1. Open Eclipse
2. Click `File` → `Import` → `Maven` → `Existing Maven Projects`
3. Browse to `SecureAccessMonitoringSystem` folder
4. Click `Finish`

### Step 2: Run the Application
1. Navigate to `src/main/java/Main.java`
2. Right-click on the file
3. Select `Run As` → `Java Application`

---

## 🔧 Method 4: Using NetBeans

### Step 1: Open Project
1. Open NetBeans
2. Click `File` → `Open Project`
3. Select the `SecureAccessMonitoringSystem` folder
4. Click `Open Project`

### Step 2: Run the Application
1. Right-click on the project in Project Explorer
2. Select `Run`

---

## 👤 Default Login Credentials

The system automatically creates default users on first run:

| Username    | Password   | Role        |
|-------------|------------|-------------|
| admin       | admin123   | Admin       |
| commander1  | pass123    | Commander   |
| officer1    | pass123    | Officer     |
| soldier1    | pass123    | Soldier     |

**Security Note:** Change these passwords after first login in production!

---

## 📦 Project Dependencies

The project uses Maven to manage these dependencies:

1. **SQLite JDBC** (3.42.0.0) - Database connectivity
2. **BCrypt** (0.10.2) - Password encryption

Maven will automatically download these when you build the project.

---

## 🗂️ Project Structure

```
SecureAccessMonitoringSystem/
├── src/
│   └── main/
│       └── java/
│           ├── Main.java                    # Entry point
│           ├── database/                    # Database layer
│           │   ├── DatabaseConnection.java
│           │   ├── UserDAO.java
│           │   ├── SessionDAO.java
│           │   ├── ActivityLogDAO.java
│           │   └── AlertDAO.java
│           ├── models/                      # Data models
│           │   ├── User.java
│           │   ├── Session.java
│           │   ├── ActivityLog.java
│           │   └── Alert.java
│           ├── ui/                          # User Interface
│           │   ├── LoginFrame.java          # ✨ FIXED LOGIN PAGE
│           │   ├── DashboardFrame.java
│           │   ├── AdminFrame.java
│           │   ├── UserManagementFrame.java
│           │   ├── SessionViewerFrame.java
│           │   └── AlertViewerFrame.java
│           ├── security/                    # Security features
│           │   ├── SessionMonitor.java
│           │   ├── AnomalyDetector.java
│           │   ├── RBACManager.java
│           │   └── CommandValidator.java
│           ├── logger/                      # Audit logging
│           │   └── AuditLogger.java
│           └── utils/                       # Utilities
│               └── UIHelper.java
├── pom.xml                                  # Maven configuration
├── sams.db                                  # SQLite database
└── audit_log.txt                            # Audit logs
```

---

## ✅ What's Been Fixed

### Login Page Improvements:
- ✅ **Input Field Width**: Increased from 450px to 480px
- ✅ **Input Field Height**: Increased from 42px to 48px
- ✅ **Text Visibility**: Light text on dark background (high contrast)
- ✅ **Login Button Width**: Matched to input fields (480px)
- ✅ **Professional Layout**: Balanced and consistent spacing

---

## 🛠️ Troubleshooting

### Issue: "Java version not compatible"
**Solution:** Make sure you have JDK 17 or higher installed
```bash
java -version
```

### Issue: "Maven command not found"
**Solution:** Install Maven or add it to your PATH
```bash
mvn -version
```

### Issue: "Database initialization failed"
**Solution:** Delete `sams.db` file and restart the application. It will recreate the database.

### Issue: "Dependencies not downloading"
**Solution:** Check internet connection and run:
```bash
mvn clean install -U
```

### Issue: "Port already in use" or "Display error"
**Solution:** Make sure no other instance is running. Kill any Java processes:
```bash
# Windows
taskkill /F /IM java.exe

# Linux/Mac
pkill java
```

---

## 🔐 Security Features

- ✅ Password hashing with BCrypt
- ✅ Session monitoring and timeout
- ✅ Failed login attempt tracking (max 5 attempts)
- ✅ Role-based access control (RBAC)
- ✅ Audit logging of all activities
- ✅ Anomaly detection
- ✅ SSL/TLS encrypted connections (simulated)

---

## 📞 Support

If you encounter any issues:
1. Check the console output for error messages
2. Review the `audit_log.txt` file
3. Ensure all dependencies are correctly installed
4. Verify Java and Maven versions

---

## 📝 License

© 2025 Defence Operations - All Rights Reserved

---

**Enjoy your Secure Access Monitoring System! 🛡️**
