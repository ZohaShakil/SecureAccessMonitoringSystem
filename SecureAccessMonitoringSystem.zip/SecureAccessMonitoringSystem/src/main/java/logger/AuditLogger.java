/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logger;

/**
 *
 * @author malai
 */

import models.ActivityLog;
import models.Alert;
import database.ActivityLogDAO;
import database.AlertDAO;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class AuditLogger {
    
    private static final List<String> activityTimeline = new CopyOnWriteArrayList<>();
    private static final String LOG_FILE = "audit_log.txt";
    private static final DateTimeFormatter formatter = 
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    private static ActivityLogDAO activityLogDAO = new ActivityLogDAO();
    private static AlertDAO alertDAO = new AlertDAO();
    
    public enum LogLevel { INFO, WARNING, ALERT, CRITICAL }
    
    // Log activity to database and file
    public static void logActivity(int userId, String username, String action, 
                                   String details, String ipAddress, boolean successful) {
        ActivityLog log = new ActivityLog(userId, username, action, details, ipAddress, successful);
        activityLogDAO.createLog(log);
        
        String entry = String.format("[%s] [INFO] %s - %s: %s",
            LocalDateTime.now().format(formatter),
            username,
            action,
            details);
        
        activityTimeline.add(entry);
        writeToFile(entry);
    }
    
    // Log alert to database and file
    public static void logAlert(String message, String details, Integer userId, 
                               String username, Alert.Severity severity) {
        Alert alert = new Alert(severity, message, details, userId, username);
        alertDAO.createAlert(alert);
        
        String entry = String.format("[%s] [%s] ALERT: %s - %s",
            LocalDateTime.now().format(formatter),
            severity,
            username != null ? username : "SYSTEM",
            message);
        
        activityTimeline.add(entry);
        writeToFile(entry);
        
        // Console output
        System.out.println("🚨 " + entry);
    }
    
    // Simplified logging methods
    public static void logActivity(String message) {
        String entry = String.format("[%s] [INFO] %s",
            LocalDateTime.now().format(formatter),
            message);
        activityTimeline.add(entry);
        writeToFile(entry);
    }
    
    public static void logAlert(String message) {
        logAlert(message, null, null, null, Alert.Severity.MEDIUM);
    }
    
    private static synchronized void writeToFile(String entry) {
        try (FileWriter fw = new FileWriter(LOG_FILE, true);
             BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write(entry);
            bw.newLine();
        } catch (IOException e) {
            System.err.println("Failed to write to log file: " + e.getMessage());
        }
    }
    
    public static List<String> getTimeline() {
        return new ArrayList<>(activityTimeline);
    }
    
    public static List<String> getRecentLogs(int count) {
        int size = activityTimeline.size();
        int fromIndex = Math.max(0, size - count);
        return new ArrayList<>(activityTimeline.subList(fromIndex, size));
    }
}