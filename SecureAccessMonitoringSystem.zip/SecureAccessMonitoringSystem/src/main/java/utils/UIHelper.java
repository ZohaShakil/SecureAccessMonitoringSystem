/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

/**
 *
 * @author malai
 */

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Professional UI Helper for Defence Operations Monitoring System
 * Provides consistent styling, modern components, and professional layouts
 */
public class UIHelper {
    
    // ============ COLOR SCHEME ============
    // Modern Military-Inspired Palette
    public static final Color PRIMARY_COLOR = new Color(13, 27, 42);        // Deep Navy
    public static final Color SECONDARY_COLOR = new Color(0, 150, 215);     // Cyber Blue
    public static final Color TERTIARY_COLOR = new Color(100, 200, 255);    // Light Blue
    
    public static final Color SUCCESS_COLOR = new Color(34, 197, 94);       // Modern Green
    public static final Color WARNING_COLOR = new Color(251, 146, 60);      // Vibrant Orange
    public static final Color DANGER_COLOR = new Color(239, 68, 68);        // Alert Red
    public static final Color INFO_COLOR = new Color(59, 130, 246);         // Info Blue
    
    public static final Color BACKGROUND_COLOR = new Color(15, 23, 42);     // Dark Background
    public static final Color SURFACE_COLOR = new Color(30, 41, 59);        // Card Surface
    public static final Color BORDER_COLOR = new Color(71, 85, 105);        // Border
    public static final Color TEXT_PRIMARY = new Color(241, 245, 250);      // Light Text
    public static final Color TEXT_SECONDARY = new Color(148, 163, 184);    // Dim Text
    
    // ============ FONTS ============
    public static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 28);
    public static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 20);
    public static final Font SUBHEADER_FONT = new Font("Segoe UI", Font.BOLD, 16);
    public static final Font NORMAL_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font SMALL_FONT = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font MONO_FONT = new Font("Consolas", Font.PLAIN, 12);
    
    // ============ BUTTON STYLES ============
    
    /**
     * Create a modern rounded button with hover effects
     * FIXED: Proper button colors with contrasting text
     */
    public static JButton createStyledButton(String text, Color backgroundColor) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                super.paintComponent(g);
            }
        };
        
        button.setFont(NORMAL_FONT);
        button.setBackground(backgroundColor);
        button.setForeground(TEXT_PRIMARY);  // Light text for visibility
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        
        // Hover effect with smooth transition
        button.addMouseListener(new MouseAdapter() {
            private Color originalBackground = backgroundColor;
            
            @Override
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(lightenColor(originalBackground, 20));
                button.setForeground(TEXT_PRIMARY);
                button.repaint();
            }
            
            @Override
            public void mouseExited(MouseEvent evt) {
                button.setBackground(originalBackground);
                button.setForeground(TEXT_PRIMARY);
                button.repaint();
            }
        });
        
        return button;
    }
    
    /**
     * Create a primary action button (Blue/Cyan)
     */
    public static JButton createPrimaryButton(String text) {
        return createStyledButton(text, SECONDARY_COLOR);
    }
    
    /**
     * Create a success button (Green)
     */
    public static JButton createSuccessButton(String text) {
        return createStyledButton(text, SUCCESS_COLOR);
    }
    
    /**
     * Create a warning/danger button (Red)
     */
    public static JButton createDangerButton(String text) {
        return createStyledButton(text, DANGER_COLOR);
    }
    
    /**
     * Create an info button (Blue)
     */
    public static JButton createInfoButton(String text) {
        return createStyledButton(text, INFO_COLOR);
    }
    
    /**
     * Create an icon button with minimal styling
     */
    public static JButton createIconButton(String text, Color color) {
        JButton button = createStyledButton(text, color);
        button.setFont(NORMAL_FONT);
        return button;
    }
    
    // ============ PANEL STYLES ============
    
    /**
     * Create a professional titled panel with modern styling
     */
    public static JPanel createTitledPanel(String title) {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                g2.setColor(SURFACE_COLOR);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                
                g2.setColor(BORDER_COLOR);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                
                super.paintComponent(g);
            }
        };
        
        panel.setBackground(SURFACE_COLOR);
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Add title label
        JLabel titleLabel = createStyledLabel(title, SUBHEADER_FONT, SECONDARY_COLOR);
        
        return panel;
    }
    
    /**
     * Create a modern card panel for data display
     */
    public static JPanel createCardPanel(String title, String value, Color accentColor) {
        JPanel card = new JPanel(new BorderLayout(10, 10)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                g2.setColor(SURFACE_COLOR);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                
                g2.setColor(accentColor);
                g2.setStroke(new BasicStroke(2.5f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                
                super.paintComponent(g);
            }
        };
        
        card.setBackground(SURFACE_COLOR);
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JLabel titleLabel = createStyledLabel(title, SMALL_FONT, TEXT_SECONDARY);
        JLabel valueLabel = createStyledLabel(value, HEADER_FONT, accentColor);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        return card;
    }
    
    // ============ INPUT FIELDS ============
    
    /**
     * Create a professional text field with modern styling
     * FIXED: Proper width (minimum 300px) so text is fully visible
     */
    public static JTextField createStyledTextField() {
        JTextField textField = new JTextField() {
            @Override
            protected void paintBorder(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                g2.setColor(BORDER_COLOR);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 6, 6);
            }
        };
        
        textField.setFont(NORMAL_FONT);
        textField.setBackground(SURFACE_COLOR);
        textField.setForeground(TEXT_PRIMARY);
        textField.setCaretColor(SECONDARY_COLOR);
        textField.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        textField.setOpaque(true);
        textField.setPreferredSize(new Dimension(300, 40));  // FIXED: Proper width
        textField.setMinimumSize(new Dimension(300, 40));
        
        return textField;
    }
    
    /**
     * Create a professional password field
     * FIXED: Proper width (minimum 300px) so password is fully visible
     */
    public static JPasswordField createStyledPasswordField() {
        JPasswordField passwordField = new JPasswordField() {
            @Override
            protected void paintBorder(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                g2.setColor(BORDER_COLOR);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 6, 6);
            }
        };
        
        passwordField.setFont(NORMAL_FONT);
        passwordField.setBackground(SURFACE_COLOR);
        passwordField.setForeground(TEXT_PRIMARY);
        passwordField.setCaretColor(SECONDARY_COLOR);
        passwordField.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        passwordField.setOpaque(true);
        passwordField.setPreferredSize(new Dimension(300, 40));  // FIXED: Proper width
        passwordField.setMinimumSize(new Dimension(300, 40));
        
        return passwordField;
    }
    
    /**
     * Create a professional text area
     */
    public static JTextArea createStyledTextArea() {
        JTextArea textArea = new JTextArea() {
            @Override
            protected void paintBorder(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                g2.setColor(BORDER_COLOR);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 6, 6);
            }
        };
        
        textArea.setFont(MONO_FONT);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setBackground(SURFACE_COLOR);
        textArea.setForeground(TEXT_PRIMARY);
        textArea.setCaretColor(SECONDARY_COLOR);
        textArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        textArea.setOpaque(true);
        
        return textArea;
    }
    
    /**
     * Create a professional combo box
     */
    public static JComboBox<String> createStyledComboBox(String[] items) {
        JComboBox<String> comboBox = new JComboBox<>(items);
        comboBox.setFont(NORMAL_FONT);
        comboBox.setBackground(SURFACE_COLOR);
        comboBox.setForeground(TEXT_PRIMARY);
        
        return comboBox;
    }
    
    // ============ LABELS ============
    
    /**
     * Create a styled label
     */
    public static JLabel createStyledLabel(String text, Font font, Color color) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(color);
        return label;
    }
    
    // ============ DIALOGS ============
    
    public static void showInfoDialog(Component parent, String message, String title) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.INFORMATION_MESSAGE);
    }
    
    public static void showWarningDialog(Component parent, String message, String title) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.WARNING_MESSAGE);
    }
    
    public static void showErrorDialog(Component parent, String message, String title) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.ERROR_MESSAGE);
    }
    
    public static boolean showConfirmDialog(Component parent, String message, String title) {
        int result = JOptionPane.showConfirmDialog(parent, message, title,
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        return result == JOptionPane.YES_OPTION;
    }
    
    // ============ UTILITY METHODS ============
    
    /**
     * Lighten a color by a certain amount
     */
    private static Color lightenColor(Color color, int amount) {
        int red = Math.min(255, color.getRed() + amount);
        int green = Math.min(255, color.getGreen() + amount);
        int blue = Math.min(255, color.getBlue() + amount);
        return new Color(red, green, blue);
    }
    
    /**
     * Darken a color by a certain amount
     */
    public static Color darkenColor(Color color, int amount) {
        int red = Math.max(0, color.getRed() - amount);
        int green = Math.max(0, color.getGreen() - amount);
        int blue = Math.max(0, color.getBlue() - amount);
        return new Color(red, green, blue);
    }
}