/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author malai
 */
import database.DatabaseConnection;
import database.UserDAO;
import models.User;
import ui.LoginFrame;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Initialize database
        System.out.println("=== SECURE ACCESS MONITORING SYSTEM ===");
        System.out.println("Initializing database...");
        DatabaseConnection.initializeDatabase();
        
        // Create default users if database is empty
        createDefaultUsers();
        
        // Set Look and Feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Launch GUI
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
    
    private static void createDefaultUsers() {
        UserDAO userDAO = new UserDAO();
        
        // Check if users exist
        if (userDAO.getAllUsers().isEmpty()) {
            System.out.println("Creating default users...");
            
            // Create Admin
            User admin = new User("admin", "admin123", "Admin", "Administrator");
            userDAO.createUser(admin);
            System.out.println("✓ Admin created: username='admin', password='admin123'");
            
            // Create Commander
            User commander = new User("commander1", "pass123", "Commander", "Major");
            userDAO.createUser(commander);
            System.out.println("✓ Commander created: username='commander1', password='pass123'");
            
            // Create Officer
            User officer = new User("officer1", "pass123", "Officer", "Captain");
            userDAO.createUser(officer);
            System.out.println("✓ Officer created: username='officer1', password='pass123'");
            
            // Create Soldier
            User soldier = new User("soldier1", "pass123", "Soldier", "Private");
            userDAO.createUser(soldier);
            System.out.println("✓ Soldier created: username='soldier1', password='pass123'");
            
            System.out.println("\nDefault users created successfully!");
        } else {
            System.out.println("Users already exist in database.");
        }
    }
}
