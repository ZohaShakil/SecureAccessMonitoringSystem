/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package security;

/**
 *
 * @author malai
 */

import models.User;
import java.util.*;

public class RBACManager {
    private Map<String, Set<String>> rolePermissions;
    private Map<String, Integer> roleHierarchy;
    
    public RBACManager() {
        rolePermissions = new HashMap<>();
        roleHierarchy = new HashMap<>();
        initializePermissions();
    }
    
    private void initializePermissions() {
        // Define role hierarchy
        roleHierarchy.put("Soldier", 1);
        roleHierarchy.put("Officer", 2);
        roleHierarchy.put("Commander", 3);
        roleHierarchy.put("Admin", 4);
        
        // Soldier permissions
        Set<String> soldierPerms = new HashSet<>(Arrays.asList(
            "VIEW_DATA",
            "VIEW_OWN_PROFILE",
            "SUBMIT_REPORT"
        ));
        
        // Officer permissions
        Set<String> officerPerms = new HashSet<>(soldierPerms);
        officerPerms.addAll(Arrays.asList(
            "ISSUE_COMMAND",
            "ACCESS_CLASSIFIED_L1",
            "VIEW_TEAM_DATA",
            "APPROVE_REPORTS"
        ));
        
        // Commander permissions
        Set<String> commanderPerms = new HashSet<>(officerPerms);
        commanderPerms.addAll(Arrays.asList(
            "EXECUTE_MISSION",
            "ACCESS_CLASSIFIED_L2",
            "MODIFY_OPERATIONS",
            "VIEW_ALL_SESSIONS",
            "FORCE_LOGOUT"
        ));
        
        // Admin permissions
        Set<String> adminPerms = new HashSet<>(commanderPerms);
        adminPerms.addAll(Arrays.asList(
            "MANAGE_USERS",
            "VIEW_AUDIT_LOGS",
            "CONFIGURE_SYSTEM",
            "ACCESS_CLASSIFIED_L3",
            "OVERRIDE_SECURITY",
            "VIEW_ALERTS",
            "MANAGE_ALERTS"
        ));
        
        rolePermissions.put("Soldier", soldierPerms);
        rolePermissions.put("Officer", officerPerms);
        rolePermissions.put("Commander", commanderPerms);
        rolePermissions.put("Admin", adminPerms);
    }
    
    public boolean hasPermission(User user, String permission) {
        if (user == null || !user.isLoggedIn()) {
            return false;
        }
        
        Set<String> perms = rolePermissions.get(user.getRole());
        return perms != null && perms.contains(permission);
    }
    
    public boolean canExecuteCommand(User user, String command) {
        String requiredPermission = getRequiredPermission(command);
        return hasPermission(user, requiredPermission);
    }
    
    private String getRequiredPermission(String command) {
        Map<String, String> commandPermissionMap = new HashMap<>();
        commandPermissionMap.put("View Data", "VIEW_DATA");
        commandPermissionMap.put("Issue Command", "ISSUE_COMMAND");
        commandPermissionMap.put("Access Classified", "ACCESS_CLASSIFIED_L1");
        commandPermissionMap.put("Execute Mission", "EXECUTE_MISSION");
        commandPermissionMap.put("Manage Users", "MANAGE_USERS");
        
        return commandPermissionMap.getOrDefault(command, "UNKNOWN");
    }
    
    public Set<String> getRolePermissions(String role) {
        return new HashSet<>(rolePermissions.getOrDefault(role, new HashSet<>()));
    }
    
    public boolean hasHigherPrivilege(String role1, String role2) {
        int level1 = roleHierarchy.getOrDefault(role1, 0);
        int level2 = roleHierarchy.getOrDefault(role2, 0);
        return level1 > level2;
    }
    
    public Set<String> getAllRoles() {
        return rolePermissions.keySet();
    }
}
