/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package security;

/**
 *
 * @author malai
 */

import models.User;
import models.Alert;
import logger.AuditLogger;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class AnomalyDetector {
    
    private static Map<String, List<Long>> failedLoginAttempts = new ConcurrentHashMap<>();
    private static Map<String, List<Long>> commandAttempts = new ConcurrentHashMap<>();
    
    private static final int MAX_FAILED_LOGINS = 3;
    private static final long FAILED_LOGIN_WINDOW = 5 * 60 * 1000; // 5 minutes
    private static final int MAX_COMMANDS_PER_MINUTE = 20;
    
    public static void recordFailedLogin(String username) {
        failedLoginAttempts.putIfAbsent(username, new ArrayList<>());
        List<Long> attempts = failedLoginAttempts.get(username);
        
        long now = System.currentTimeMillis();
        attempts.add(now);
        
        // Remove old attempts
        attempts.removeIf(time -> (now - time) > FAILED_LOGIN_WINDOW);
        
        if (attempts.size() >= MAX_FAILED_LOGINS) {
            AuditLogger.logAlert(
                "Multiple failed login attempts detected",
                String.format("Username: %s, Attempts: %d in last 5 minutes", 
                    username, attempts.size()),
                null,
                username,
                Alert.Severity.CRITICAL
            );
        }
    }
    
    public static void recordSuccessfulLogin(String username) {
        failedLoginAttempts.remove(username);
    }
    
    public static void recordCommandExecution(User user, String command) {
        String key = user.getUsername();
        commandAttempts.putIfAbsent(key, new ArrayList<>());
        List<Long> attempts = commandAttempts.get(key);
        
        long now = System.currentTimeMillis();
        attempts.add(now);
        
        // Remove attempts older than 1 minute
        attempts.removeIf(time -> (now - time) > 60000);
        
        if (attempts.size() >= MAX_COMMANDS_PER_MINUTE) {
            AuditLogger.logAlert(
                "Suspicious command frequency detected",
                String.format("User: %s executed %d commands in 1 minute", 
                    user.getUsername(), attempts.size()),
                user.getUserId(),
                user.getUsername(),
                Alert.Severity.HIGH
            );
        }
    }
    
    public static boolean checkAccessTiming() {
        int hour = java.time.LocalTime.now().getHour();
        return hour >= 6 && hour <= 23;
    }
    
    public static void detectPrivilegeEscalation(User user, String attemptedAction) {
        AuditLogger.logAlert(
            "Privilege escalation attempt detected",
            String.format("User: %s (Role: %s) attempted: %s",
                user.getUsername(), user.getRole(), attemptedAction),
            user.getUserId(),
            user.getUsername(),
            Alert.Severity.CRITICAL
        );
    }
    
    public static void clearUserData(String username) {
        failedLoginAttempts.remove(username);
        commandAttempts.remove(username);
    }
}