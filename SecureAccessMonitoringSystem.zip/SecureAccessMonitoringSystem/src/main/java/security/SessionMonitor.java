/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package security;

/**
 *
 * @author malai
 */

import models.User;
import models.Session;
import models.Alert;
import database.SessionDAO;
import logger.AuditLogger;

import java.util.*;
import java.util.concurrent.*;

public class SessionMonitor {
    private static Map<String, SessionInfo> activeSessions = new ConcurrentHashMap<>();
    private static Timer timer;
    private static SessionDAO sessionDAO = new SessionDAO();
    
    private static final long TIMEOUT = 15 * 60 * 1000; // 15 minutes
    private static final int NORMAL_HOUR_START = 6;
    private static final int NORMAL_HOUR_END = 23;
    
    static {
        startGlobalMonitoring();
    }
    
    private static class SessionInfo {
        User user;
        Session session;
        long lastActivity;
        String sessionId;
        
        SessionInfo(User user, Session session) {
            this.user = user;
            this.session = session;
            this.sessionId = session.getSessionId();
            this.lastActivity = System.currentTimeMillis();
        }
    }
    
    public static String startSession(User user, String ipAddress) {
        Session session = new Session(user.getUserId(), ipAddress);
        sessionDAO.createSession(session);
        
        activeSessions.put(session.getSessionId(), new SessionInfo(user, session));
        
        AuditLogger.logActivity(
            user.getUserId(),
            user.getUsername(),
            "SESSION_STARTED",
            "User logged in from " + ipAddress,
            ipAddress,
            true
        );
        
        return session.getSessionId();
    }
    
    public static void updateActivity(String sessionId) {
        SessionInfo info = activeSessions.get(sessionId);
        if (info != null) {
            info.lastActivity = System.currentTimeMillis();
            info.user.updateActivity();
            info.session.updateActivity();
        }
    }
    
    public static void endSession(String sessionId) {
        SessionInfo info = activeSessions.remove(sessionId);
        if (info != null) {
            sessionDAO.endSession(sessionId);
            info.session.terminate();
            
            AuditLogger.logActivity(
                info.user.getUserId(),
                info.user.getUsername(),
                "SESSION_ENDED",
                "User logged out",
                info.session.getIpAddress(),
                true
            );
        }
    }
    
    private static void startGlobalMonitoring() {
        timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                int hour = java.time.LocalTime.now().getHour();
                
                for (Map.Entry<String, SessionInfo> entry : activeSessions.entrySet()) {
                    SessionInfo info = entry.getValue();
                    
                    // Check for timeout
                    if (now - info.lastActivity > TIMEOUT) {
                        AuditLogger.logAlert(
                            "Unattended session detected",
                            String.format("User: %s, Session: %s, Idle for: %d minutes",
                                info.user.getUsername(),
                                info.sessionId,
                                (now - info.lastActivity) / 60000),
                            info.user.getUserId(),
                            info.user.getUsername(),
                            Alert.Severity.MEDIUM
                        );
                    }
                    
                    // Check for abnormal hours
                    if (hour < NORMAL_HOUR_START || hour > NORMAL_HOUR_END) {
                        AuditLogger.logAlert(
                            "Abnormal access timing detected",
                            String.format("User: %s accessing system at %02d:00 hours",
                                info.user.getUsername(), hour),
                            info.user.getUserId(),
                            info.user.getUsername(),
                            Alert.Severity.HIGH
                        );
                    }
                }
            }
        }, 0, 60 * 1000); // Check every minute
    }
    
    public static List<SessionInfo> getActiveSessions() {
        return new ArrayList<>(activeSessions.values());
    }
    
    public static boolean forceLogout(String sessionId) {
        SessionInfo info = activeSessions.get(sessionId);
        if (info != null) {
            AuditLogger.logAlert(
                "Force logout executed",
                "Session: " + sessionId + ", User: " + info.user.getUsername(),
                info.user.getUserId(),
                info.user.getUsername(),
                Alert.Severity.MEDIUM
            );
            endSession(sessionId);
            return true;
        }
        return false;
    }
    
    public static int getActiveSessionCount() {
        return activeSessions.size();
    }
    
    public static SessionInfo getSessionInfo(String sessionId) {
        return activeSessions.get(sessionId);
    }
}