/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package security;

/**
 *
 * @author malai
 */

import models.User;
import logger.AuditLogger;

public class CommandValidator {
    private RBACManager rbac;
    
    public CommandValidator(RBACManager rbac) {
        this.rbac = rbac;
    }
    
    public boolean validateAndExecute(User user, String command) {
        if (user == null || !user.isLoggedIn()) {
            AuditLogger.logAlert("Command attempt by logged out user");
            return false;
        }
        
        if (!rbac.canExecuteCommand(user, command)) {
            AuditLogger.logAlert(
                "Unauthorized command attempt",
                String.format("User: %s (Role: %s) attempted: %s", 
                    user.getUsername(), user.getRole(), command),
                user.getUserId(),
                user.getUsername(),
                models.Alert.Severity.HIGH
            );
            return false;
        }
        
        // Log successful command execution
        AuditLogger.logActivity(
            user.getUserId(),
            user.getUsername(),
            "COMMAND_EXECUTED",
            command,
            "127.0.0.1",
            true
        );
        
        return true;
    }
    
    public boolean validateCommand(User user, String command) {
        return rbac.canExecuteCommand(user, command);
    }
}