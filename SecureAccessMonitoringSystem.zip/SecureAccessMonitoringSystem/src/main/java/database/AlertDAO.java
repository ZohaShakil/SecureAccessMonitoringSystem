/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

/**
 *
 * @author malai
 */

import models.Alert;
import models.Alert.Severity;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlertDAO {
    
    public boolean createAlert(Alert alert) {
        String sql = "INSERT INTO alerts (severity, message, details, user_id, username) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, alert.getSeverity().name());
            pstmt.setString(2, alert.getMessage());
            pstmt.setString(3, alert.getDetails());
            if (alert.getUserId() != null) {
                pstmt.setInt(4, alert.getUserId());
            } else {
                pstmt.setNull(4, Types.INTEGER);
            }
            pstmt.setString(5, alert.getUsername());
            
            int affected = pstmt.executeUpdate();
            if (affected > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    alert.setAlertId(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Create alert error: " + e.getMessage());
        }
        return false;
    }
    
    public List<Alert> getAllAlerts() {
        List<Alert> alerts = new ArrayList<>();
        String sql = "SELECT * FROM alerts ORDER BY timestamp DESC LIMIT 500";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Integer userId = rs.getObject("user_id", Integer.class);
                
                alerts.add(new Alert(
                    rs.getInt("alert_id"),
                    Severity.valueOf(rs.getString("severity")),
                    rs.getString("message"),
                    rs.getString("details"),
                    userId,
                    rs.getString("username"),
                    rs.getTimestamp("timestamp").toLocalDateTime(),
                    rs.getInt("acknowledged") == 1
                ));
            }
        } catch (SQLException e) {
            System.err.println("Get all alerts error: " + e.getMessage());
        }
        return alerts;
    }
    
    public List<Alert> getUnacknowledgedAlerts() {
        List<Alert> alerts = new ArrayList<>();
        String sql = "SELECT * FROM alerts WHERE acknowledged = 0 ORDER BY timestamp DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Integer userId = rs.getObject("user_id", Integer.class);
                
                alerts.add(new Alert(
                    rs.getInt("alert_id"),
                    Severity.valueOf(rs.getString("severity")),
                    rs.getString("message"),
                    rs.getString("details"),
                    userId,
                    rs.getString("username"),
                    rs.getTimestamp("timestamp").toLocalDateTime(),
                    rs.getInt("acknowledged") == 1
                ));
            }
        } catch (SQLException e) {
            System.err.println("Get unacknowledged alerts error: " + e.getMessage());
        }
        return alerts;
    }
    
    public boolean acknowledgeAlert(int alertId) {
        String sql = "UPDATE alerts SET acknowledged = 1 WHERE alert_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, alertId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Acknowledge alert error: " + e.getMessage());
        }
        return false;
    }
}
