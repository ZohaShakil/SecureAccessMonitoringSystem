/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

/**
 *
 * @author malai
 */

import models.ActivityLog;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ActivityLogDAO {
    
    public boolean createLog(ActivityLog log) {
        String sql = "INSERT INTO activity_logs (user_id, username, action, details, ip_address, successful) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, log.getUserId());
            pstmt.setString(2, log.getUsername());
            pstmt.setString(3, log.getAction());
            pstmt.setString(4, log.getDetails());
            pstmt.setString(5, log.getIpAddress());
            pstmt.setInt(6, log.isSuccessful() ? 1 : 0);
            
            int affected = pstmt.executeUpdate();
            if (affected > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    log.setLogId(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Create log error: " + e.getMessage());
        }
        return false;
    }
    
    public List<ActivityLog> getAllLogs() {
        List<ActivityLog> logs = new ArrayList<>();
        String sql = "SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT 1000";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                logs.add(new ActivityLog(
                    rs.getInt("log_id"),
                    rs.getInt("user_id"),
                    rs.getString("username"),
                    rs.getString("action"),
                    rs.getString("details"),
                    rs.getTimestamp("timestamp").toLocalDateTime(),
                    rs.getString("ip_address"),
                    rs.getInt("successful") == 1
                ));
            }
        } catch (SQLException e) {
            System.err.println("Get all logs error: " + e.getMessage());
        }
        return logs;
    }
    
    public List<ActivityLog> getLogsByUser(int userId) {
        List<ActivityLog> logs = new ArrayList<>();
        String sql = "SELECT * FROM activity_logs WHERE user_id = ? ORDER BY timestamp DESC LIMIT 100";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                logs.add(new ActivityLog(
                    rs.getInt("log_id"),
                    rs.getInt("user_id"),
                    rs.getString("username"),
                    rs.getString("action"),
                    rs.getString("details"),
                    rs.getTimestamp("timestamp").toLocalDateTime(),
                    rs.getString("ip_address"),
                    rs.getInt("successful") == 1
                ));
            }
        } catch (SQLException e) {
            System.err.println("Get logs by user error: " + e.getMessage());
        }
        return logs;
    }
}
