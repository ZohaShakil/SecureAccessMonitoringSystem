/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

/**
 *
 * @author malai
 */

import models.Session;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SessionDAO {
    
    public boolean createSession(Session session) {
        String sql = "INSERT INTO sessions (session_id, user_id, ip_address) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, session.getSessionId());
            pstmt.setInt(2, session.getUserId());
            pstmt.setString(3, session.getIpAddress());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Create session error: " + e.getMessage());
        }
        return false;
    }
    
    public boolean endSession(String sessionId) {
        String sql = "UPDATE sessions SET logout_time = CURRENT_TIMESTAMP, is_active = 0 WHERE session_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, sessionId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("End session error: " + e.getMessage());
        }
        return false;
    }
    
    public List<Session> getActiveSessions() {
        List<Session> sessions = new ArrayList<>();
        String sql = "SELECT * FROM sessions WHERE is_active = 1 ORDER BY login_time DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                LocalDateTime logoutTime = null;
                Timestamp logoutTs = rs.getTimestamp("logout_time");
                if (logoutTs != null) {
                    logoutTime = logoutTs.toLocalDateTime();
                }
                
                sessions.add(new Session(
                    rs.getString("session_id"),
                    rs.getInt("user_id"),
                    rs.getTimestamp("login_time").toLocalDateTime(),
                    logoutTime,
                    rs.getString("ip_address"),
                    rs.getInt("is_active") == 1
                ));
            }
        } catch (SQLException e) {
            System.err.println("Get active sessions error: " + e.getMessage());
        }
        return sessions;
    }
    
    public List<Session> getAllSessions() {
        List<Session> sessions = new ArrayList<>();
        String sql = "SELECT * FROM sessions ORDER BY login_time DESC LIMIT 100";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                LocalDateTime logoutTime = null;
                Timestamp logoutTs = rs.getTimestamp("logout_time");
                if (logoutTs != null) {
                    logoutTime = logoutTs.toLocalDateTime();
                }
                
                sessions.add(new Session(
                    rs.getString("session_id"),
                    rs.getInt("user_id"),
                    rs.getTimestamp("login_time").toLocalDateTime(),
                    logoutTime,
                    rs.getString("ip_address"),
                    rs.getInt("is_active") == 1
                ));
            }
        } catch (SQLException e) {
            System.err.println("Get all sessions error: " + e.getMessage());
        }
        return sessions;
    }
}