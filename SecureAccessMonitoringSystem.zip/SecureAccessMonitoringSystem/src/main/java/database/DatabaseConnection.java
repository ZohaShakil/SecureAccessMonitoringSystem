/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

/**
 *
 * @author malai
 */

import java.sql.*;
import java.io.File;
import models.User;

public class DatabaseConnection {
    // Use absolute path in user home directory
    private static final String DB_DIR = System.getProperty("user.home") + "/SAMSDatabase";
    private static final String DB_URL = "jdbc:sqlite:" + DB_DIR + "/sams.db";
    private static Connection connection = null;
    
    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                // Create directory if it doesn't exist
                File dbDirectory = new File(DB_DIR);
                if (!dbDirectory.exists()) {
                    dbDirectory.mkdirs();
                    System.out.println("Created database directory: " + DB_DIR);
                }
                
                Class.forName("org.sqlite.JDBC");
                connection = DriverManager.getConnection(DB_URL);
                System.out.println("Database connected: " + DB_URL);
            }
            return connection;
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    public static void initializeDatabase() {
        // Check if database file already exists
        File dbFile = new File(DB_DIR + "/sams.db");
        boolean isNewDatabase = !dbFile.exists();
        
        if (isNewDatabase) {
            System.out.println("Creating new database...");
        } else {
            System.out.println("Found existing database at: " + dbFile.getAbsolutePath());
        }
        
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            
            // Create users table
            stmt.execute(
                "CREATE TABLE IF NOT EXISTS users (" +
                "user_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL, " +
                "role TEXT NOT NULL, " +
                "rank TEXT NOT NULL, " +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                "is_active INTEGER DEFAULT 1)"
            );
            
            // Create sessions table
            stmt.execute(
                "CREATE TABLE IF NOT EXISTS sessions (" +
                "session_id TEXT PRIMARY KEY, " +
                "user_id INTEGER NOT NULL, " +
                "login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                "logout_time TIMESTAMP, " +
                "ip_address TEXT, " +
                "is_active INTEGER DEFAULT 1, " +
                "FOREIGN KEY (user_id) REFERENCES users(user_id))"
            );
            
            // Create activity_logs table
            stmt.execute(
                "CREATE TABLE IF NOT EXISTS activity_logs (" +
                "log_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "username TEXT NOT NULL, " +
                "action TEXT NOT NULL, " +
                "details TEXT, " +
                "timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                "ip_address TEXT, " +
                "successful INTEGER DEFAULT 1, " +
                "FOREIGN KEY (user_id) REFERENCES users(user_id))"
            );
            
            // Create alerts table
            stmt.execute(
                "CREATE TABLE IF NOT EXISTS alerts (" +
                "alert_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "severity TEXT NOT NULL, " +
                "message TEXT NOT NULL, " +
                "details TEXT, " +
                "user_id INTEGER, " +
                "username TEXT, " +
                "timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                "acknowledged INTEGER DEFAULT 0, " +
                "FOREIGN KEY (user_id) REFERENCES users(user_id))"
            );
            
            System.out.println("Database tables initialized");
            
            // Only create default users if this is a NEW database
            if (isNewDatabase) {
                System.out.println("Creating default users...");
                createDefaultUsers();
            } else {
                System.out.println("Using existing user data");
            }
            
        } catch (SQLException e) {
            System.err.println("Failed to initialize database: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static void createDefaultUsers() {
        database.UserDAO userDAO = new database.UserDAO();
        
        // Check if users already exist
        if (userDAO.getAllUsers().size() > 0) {
            System.out.println("Users already exist in database");
            return;
        }
        
        try (Connection conn = getConnection()) {
            User admin = new User("admin", "admin123", "Admin", "Administrator");
            userDAO.createUser(admin);
            System.out.println("Admin created: username='admin', password='admin123'");
            
            User commander = new User("commander1", "pass123", "Commander", "Major");
            userDAO.createUser(commander);
            System.out.println("Commander created: username='commander1', password='pass123'");
            
            User officer = new User("officer1", "pass123", "Officer", "Captain");
            userDAO.createUser(officer);
            System.out.println("Officer created: username='officer1', password='pass123'");
            
            User soldier = new User("soldier1", "pass123", "Soldier", "Private");
            userDAO.createUser(soldier);
            System.out.println("Soldier created: username='soldier1', password='pass123'");
            
            System.out.println("\nDefault users created successfully!");
            
        } catch (Exception e) {
            System.err.println("Error creating default users: " + e.getMessage());
        }
    }
    
    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database connection closed");
            }
        } catch (SQLException e) {
            System.err.println("Failed to close connection: " + e.getMessage());
        }
    }
    
    // Method to get database file location (useful for debugging)
    public static String getDatabaseLocation() {
        return DB_DIR + "/sams.db";
    }
}