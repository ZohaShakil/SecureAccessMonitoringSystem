/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

/**
 *
 * @author malai
 */

import models.User;
import models.Session;
import database.SessionDAO;
import database.UserDAO;
import security.SessionMonitor;
import logger.AuditLogger;
import utils.UIHelper;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import javax.swing.table.JTableHeader;  
import java.util.List;

/**
 * Professional Session Viewer Frame for Active Session Monitoring
 * Features: Real-time updates, force logout, professional UI, color-coded status
 * FIXED: Proper button colors and styling
 */
public class SessionViewerFrame extends JFrame {
    private User user;
    private SessionDAO sessionDAO;
    private UserDAO userDAO;
    private JTable sessionTable;
    private DefaultTableModel tableModel;
    private JLabel countLabel;
    private Timer autoRefreshTimer;
    
    public SessionViewerFrame(User user) {
        this.user = user;
        this.sessionDAO = new SessionDAO();
        this.userDAO = new UserDAO();
        initializeUI();
        loadSessions();
        startAutoRefresh();
    }
    
    private void initializeUI() {
        setTitle("Active Sessions Monitor - " + user.getUsername());
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(UIHelper.BACKGROUND_COLOR);
        
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(UIHelper.BACKGROUND_COLOR);
        
        // Header
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Content
        JPanel contentPanel = createContentPanel();
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Footer
        JPanel footerPanel = createFooterPanel();
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
        
        // Handle frame closing
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                if (autoRefreshTimer != null) {
                    autoRefreshTimer.stop();
                }
                dispose();
            }
        });
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(UIHelper.PRIMARY_COLOR);
                g2.fillRect(0, 0, getWidth(), getHeight());
                
                g2.setColor(UIHelper.SUCCESS_COLOR);
                g2.setStroke(new BasicStroke(2));
                g2.drawLine(0, getHeight() - 1, getWidth(), getHeight() - 1);
                
                super.paintComponent(g);
            }
        };
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        
        JLabel titleLabel = UIHelper.createStyledLabel(
            "👥 ACTIVE SESSIONS MONITOR",
            UIHelper.TITLE_FONT,
            UIHelper.SECONDARY_COLOR
        );
        
        countLabel = UIHelper.createStyledLabel(
            "Loading...",
            UIHelper.HEADER_FONT,
            UIHelper.SUCCESS_COLOR
        );
        
        panel.add(titleLabel, BorderLayout.WEST);
        panel.add(countLabel, BorderLayout.EAST);
        
        return panel;
    }
    
    private JPanel createContentPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(UIHelper.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 0, 20));
        
        // Table panel
        JPanel tablePanel = UIHelper.createTitledPanel("Current Active Sessions");
        tablePanel.setLayout(new BorderLayout());
        
        String[] columnNames = {"Session ID", "User ID", "Username", "Login Time", "IP Address", "Status", "Duration"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        sessionTable = new JTable(tableModel);
        setupTableAppearance();
        
        JScrollPane scrollPane = new JScrollPane(sessionTable);
        scrollPane.setBackground(UIHelper.BACKGROUND_COLOR);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(UIHelper.BACKGROUND_COLOR);
        
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        panel.add(tablePanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private void setupTableAppearance() {
        sessionTable.setFont(UIHelper.NORMAL_FONT);
        sessionTable.setRowHeight(36);
        sessionTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        sessionTable.setGridColor(UIHelper.BORDER_COLOR);
        sessionTable.setBackground(UIHelper.SURFACE_COLOR);
        sessionTable.setForeground(UIHelper.TEXT_PRIMARY);
        sessionTable.setSelectionBackground(UIHelper.SECONDARY_COLOR);
        sessionTable.setSelectionForeground(UIHelper.TEXT_PRIMARY);
        
        // Header styling
        JTableHeader header = sessionTable.getTableHeader();
        header.setFont(UIHelper.SUBHEADER_FONT);
        header.setBackground(UIHelper.PRIMARY_COLOR);
        header.setForeground(UIHelper.SECONDARY_COLOR);
        header.setPreferredSize(new Dimension(100, 45));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, UIHelper.SECONDARY_COLOR));
        
        // Cell renderer with color coding
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                JLabel label = (JLabel) c;
                label.setFont(UIHelper.NORMAL_FONT);
                label.setHorizontalAlignment(JLabel.CENTER);
                
                // Status column color coding
                if (column == 5 && value != null) {
                    String status = value.toString();
                    if (status.equals("Active")) {
                        label.setForeground(UIHelper.SUCCESS_COLOR);
                        label.setText("🟢 ACTIVE");
                    } else {
                        label.setForeground(UIHelper.WARNING_COLOR);
                        label.setText("🟡 IDLE");
                    }
                }
                
                if (!isSelected) {
                    label.setBackground(row % 2 == 0 ? UIHelper.SURFACE_COLOR : UIHelper.PRIMARY_COLOR);
                    label.setOpaque(true);
                }
                
                return label;
            }
        };
        
        for (int i = 0; i < sessionTable.getColumnCount(); i++) {
            sessionTable.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }
        
        // Set column widths
        int[] widths = {280, 80, 140, 180, 130, 120, 120};
        for (int i = 0; i < widths.length; i++) {
            sessionTable.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }
    }
    
    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        panel.setBackground(UIHelper.PRIMARY_COLOR);
        panel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIHelper.BORDER_COLOR));
        
        // FIXED: Use new button styling methods with proper colors
        JButton refreshBtn = UIHelper.createInfoButton("🔄 Refresh");
        refreshBtn.setPreferredSize(new Dimension(140, 40));
        refreshBtn.addActionListener(e -> loadSessions());
        
        JButton forceLogoutBtn = UIHelper.createDangerButton("🚪 Force Logout");
        forceLogoutBtn.setPreferredSize(new Dimension(170, 40));
        forceLogoutBtn.addActionListener(e -> forceLogoutSelected());
        
        JButton closeBtn = UIHelper.createDangerButton("✖️ Close");
        closeBtn.setPreferredSize(new Dimension(120, 40));
        closeBtn.addActionListener(e -> {
            if (autoRefreshTimer != null) {
                autoRefreshTimer.stop();
            }
            dispose();
        });
        
        panel.add(refreshBtn);
        panel.add(forceLogoutBtn);
        panel.add(closeBtn);
        
        return panel;
    }
    
    private void loadSessions() {
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        tableModel.setRowCount(0);
        
        SwingWorker<List<Session>, Void> worker = new SwingWorker<List<Session>, Void>() {
            @Override
            protected List<Session> doInBackground() {
                return sessionDAO.getActiveSessions();
            }
            
            @Override
            protected void done() {
                try {
                    List<Session> sessions = get();
                    
                    for (Session session : sessions) {
                        User sessionUser = userDAO.getUserById(session.getUserId());
                        String username = sessionUser != null ? sessionUser.getUsername() : "Unknown";
                        
                        // Calculate duration
                        long duration = java.time.Duration.between(
                            session.getLoginTime(),
                            java.time.LocalDateTime.now()
                        ).getSeconds();
                        String durationStr = formatDuration(duration);
                        
                        Object[] row = {
                            session.getSessionId(),
                            session.getUserId(),
                            username,
                            session.getLoginTime().format(
                                java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                            session.getIpAddress(),
                            session.isActive() ? "Active" : "Inactive",
                            durationStr
                        };
                        tableModel.addRow(row);
                    }
                    
                    updateSessionCount(sessions.size());
                    setCursor(Cursor.getDefaultCursor());
                    
                } catch (Exception e) {
                    setCursor(Cursor.getDefaultCursor());
                    UIHelper.showErrorDialog(SessionViewerFrame.this,
                        "Error loading sessions: " + e.getMessage(),
                        "Error");
                }
            }
        };
        
        worker.execute();
    }
    
    private String formatDuration(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, secs);
    }
    
    private void updateSessionCount(int count) {
        countLabel.setText("Active: " + count + " sessions");
    }
    
    private void forceLogoutSelected() {
        int selectedRow = sessionTable.getSelectedRow();
        
        if (selectedRow == -1) {
            UIHelper.showWarningDialog(this,
                "Please select a session to force logout.",
                "No Selection");
            return;
        }
        
        String sessionId = (String) tableModel.getValueAt(selectedRow, 0);
        String username = (String) tableModel.getValueAt(selectedRow, 2);
        
        if (UIHelper.showConfirmDialog(this,
            "⚠️ FORCE LOGOUT WARNING\n\n" +
            "You are about to forcibly terminate the session for:\n\n" +
            "Username: " + username + "\n" +
            "Session ID: " + sessionId.substring(0, Math.min(20, sessionId.length())) + "...\n\n" +
            "This action will:\n" +
            "• Immediately terminate their session\n" +
            "• Log them out of the system\n" +
            "• Be recorded in the audit trail\n\n" +
            "Are you absolutely sure?",
            "Confirm Force Logout")) {
            
            boolean success = SessionMonitor.forceLogout(sessionId);
            
            if (success) {
                UIHelper.showInfoDialog(this,
                    "✓ Force logout successful\n\n" +
                    "User: " + username + "\n" +
                    "Terminated at: " + java.time.LocalDateTime.now().format(
                        java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                    "Success");
                
                AuditLogger.logActivity(user.getUserId(), user.getUsername(),
                    "FORCE_LOGOUT", "Forced logout of user: " + username,
                    "127.0.0.1", true);
                
                loadSessions();
            } else {
                UIHelper.showErrorDialog(this,
                    "Failed to force logout user.\n\n" +
                    "The session may have already ended.",
                    "Error");
            }
        }
    }
    
    private void startAutoRefresh() {
        autoRefreshTimer = new Timer(30000, e -> loadSessions());
        autoRefreshTimer.start();
    }
}