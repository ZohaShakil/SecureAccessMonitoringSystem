/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

/**
 *
 * @author malai
 */

import models.User;
import database.UserDAO;
import security.RBACManager;
import logger.AuditLogger;
import utils.UIHelper;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;

/**
 * Professional User Management Frame
 * Features: Advanced table rendering, Role-based controls, Audit logging, Security restrictions
 * FIXED: Proper button colors, input field widths, and styling
 */
public class UserManagementFrame extends JFrame {
    private User currentUser;
    private UserDAO userDAO;
    private RBACManager rbac;
    private JTable userTable;
    private DefaultTableModel tableModel;
    private JLabel statsLabel;
    
    public UserManagementFrame(User currentUser) {
        this.currentUser = currentUser;
        this.userDAO = new UserDAO();
        this.rbac = new RBACManager();
        initializeUI();
        loadUsers();
    }
    
    private void initializeUI() {
        setTitle("User Management Console - " + currentUser.getUsername());
        setSize(1300, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(UIHelper.BACKGROUND_COLOR);
        
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(UIHelper.BACKGROUND_COLOR);
        
        // Header
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Content
        JPanel contentPanel = createContentPanel();
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Footer
        JPanel footerPanel = createFooterPanel();
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(UIHelper.PRIMARY_COLOR);
                g2.fillRect(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        
        JLabel titleLabel = UIHelper.createStyledLabel(
            "👤 USER MANAGEMENT CONSOLE",
            UIHelper.TITLE_FONT,
            UIHelper.SECONDARY_COLOR
        );
        
        statsLabel = UIHelper.createStyledLabel(
            "Loading...",
            UIHelper.NORMAL_FONT,
            UIHelper.TEXT_SECONDARY
        );
        
        panel.add(titleLabel, BorderLayout.WEST);
        panel.add(statsLabel, BorderLayout.EAST);
        
        return panel;
    }
    
    private JPanel createContentPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(UIHelper.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Table panel
        JPanel tablePanel = UIHelper.createTitledPanel("Registered Users");
        tablePanel.setLayout(new BorderLayout());
        
        // Create table
        String[] columnNames = {"ID", "Username", "Role", "Rank", "Status", "Created"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        userTable = new JTable(tableModel);
        setupTableAppearance();
        
        JScrollPane scrollPane = new JScrollPane(userTable);
        scrollPane.setBackground(UIHelper.BACKGROUND_COLOR);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(UIHelper.BACKGROUND_COLOR);
        
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        panel.add(tablePanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private void setupTableAppearance() {
        userTable.setFont(UIHelper.NORMAL_FONT);
        userTable.setRowHeight(40);
        userTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        userTable.setGridColor(UIHelper.BORDER_COLOR);
        userTable.setBackground(UIHelper.SURFACE_COLOR);
        userTable.setForeground(UIHelper.TEXT_PRIMARY);
        userTable.setSelectionBackground(UIHelper.SECONDARY_COLOR);
        userTable.setSelectionForeground(UIHelper.TEXT_PRIMARY);
        
        // Header styling
        JTableHeader header = userTable.getTableHeader();
        header.setFont(UIHelper.SUBHEADER_FONT);
        header.setBackground(UIHelper.PRIMARY_COLOR);
        header.setForeground(UIHelper.SECONDARY_COLOR);
        header.setPreferredSize(new Dimension(100, 45));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, UIHelper.SECONDARY_COLOR));
        
        // Cell renderer for centered alignment
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                JLabel label = (JLabel) c;
                label.setHorizontalAlignment(JLabel.CENTER);
                label.setFont(UIHelper.NORMAL_FONT);
                
                // Status column color coding
                if (column == 4 && value != null) {
                    String status = value.toString();
                    if (status.contains("Active")) {
                        label.setForeground(UIHelper.SUCCESS_COLOR);
                        label.setText("✓ Active");
                    } else {
                        label.setForeground(UIHelper.DANGER_COLOR);
                        label.setText("✗ Inactive");
                    }
                }
                
                if (!isSelected) {
                    label.setBackground(row % 2 == 0 ? UIHelper.SURFACE_COLOR : UIHelper.PRIMARY_COLOR);
                    label.setOpaque(true);
                }
                
                return label;
            }
        };
        
        for (int i = 0; i < userTable.getColumnCount(); i++) {
            userTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        
        // Set column widths
        int[] widths = {50, 150, 120, 120, 100, 120};
        for (int i = 0; i < widths.length; i++) {
            userTable.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }
    }
    
    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        panel.setBackground(UIHelper.PRIMARY_COLOR);
        panel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIHelper.BORDER_COLOR));
        
        // FIXED: Use new button styling methods with proper colors
        JButton addBtn = UIHelper.createSuccessButton("➕ Add User");
        addBtn.setPreferredSize(new Dimension(160, 40));
        addBtn.addActionListener(e -> showAddUserDialog());
        
        JButton editBtn = UIHelper.createPrimaryButton("✏️ Edit User");
        editBtn.setPreferredSize(new Dimension(150, 40));
        editBtn.addActionListener(e -> showEditUserDialog());
        
        JButton deleteBtn = UIHelper.createDangerButton("🗑️ Deactivate");
        deleteBtn.setPreferredSize(new Dimension(150, 40));
        deleteBtn.addActionListener(e -> deactivateUser());
        
        JButton refreshBtn = UIHelper.createInfoButton("🔄 Refresh");
        refreshBtn.setPreferredSize(new Dimension(130, 40));
        refreshBtn.addActionListener(e -> loadUsers());
        
        JButton closeBtn = UIHelper.createDangerButton("✖️ Close");
        closeBtn.setPreferredSize(new Dimension(120, 40));
        closeBtn.addActionListener(e -> dispose());
        
        panel.add(addBtn);
        panel.add(editBtn);
        panel.add(deleteBtn);
        panel.add(refreshBtn);
        panel.add(closeBtn);
        
        return panel;
    }
    
    private void loadUsers() {
        tableModel.setRowCount(0);
        List<User> users = userDAO.getAllUsers();
        
        for (User user : users) {
            Object[] row = {
                user.getUserId(),
                user.getUsername(),
                user.getRole(),
                user.getRank(),
                user.isActive() ? "Active" : "Inactive",
                "N/A"
            };
            tableModel.addRow(row);
        }
        
        updateStats(users.size());
    }
    
    private void updateStats(int totalUsers) {
        long activeCount = userDAO.getAllUsers().stream().filter(User::isActive).count();
        statsLabel.setText("Total Users: " + totalUsers + " | Active: " + activeCount);
    }
    
    // ============ ADD USER DIALOG ============
    
    private void showAddUserDialog() {
        JDialog dialog = new JDialog(this, "➕ Add New User", true);
        dialog.setSize(550, 550);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(UIHelper.BACKGROUND_COLOR);
        
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(UIHelper.BACKGROUND_COLOR);
        
        // Header
        JPanel headerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(UIHelper.PRIMARY_COLOR);
                g2.fillRect(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };
        headerPanel.setOpaque(false);
        headerPanel.setPreferredSize(new Dimension(550, 70));
        JLabel headerLabel = UIHelper.createStyledLabel(
            "Add New User",
            UIHelper.SUBHEADER_FONT,
            UIHelper.SECONDARY_COLOR
        );
        headerPanel.add(headerLabel);
        
        // Form panel with proper spacing
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 15, 20));
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        formPanel.setBackground(UIHelper.BACKGROUND_COLOR);
        
        // Username field
        JLabel usernameLabel = UIHelper.createStyledLabel("Username:", UIHelper.NORMAL_FONT, UIHelper.TEXT_PRIMARY);
        JTextField usernameField = UIHelper.createStyledTextField();
        usernameField.setPreferredSize(new Dimension(200, 40));
        
        // Password field
        JLabel passwordLabel = UIHelper.createStyledLabel("Password:", UIHelper.NORMAL_FONT, UIHelper.TEXT_PRIMARY);
        JPasswordField passwordField = UIHelper.createStyledPasswordField();
        passwordField.setPreferredSize(new Dimension(200, 40));
        
        // Role combo
        JLabel roleLabel = UIHelper.createStyledLabel("Role:", UIHelper.NORMAL_FONT, UIHelper.TEXT_PRIMARY);
        String[] roles = {"Soldier", "Officer", "Commander", "Admin"};
        JComboBox<String> roleCombo = UIHelper.createStyledComboBox(roles);
        roleCombo.setPreferredSize(new Dimension(200, 40));
        
        // Rank field
        JLabel rankLabel = UIHelper.createStyledLabel("Rank:", UIHelper.NORMAL_FONT, UIHelper.TEXT_PRIMARY);
        JTextField rankField = UIHelper.createStyledTextField();
        rankField.setPreferredSize(new Dimension(200, 40));
        
        formPanel.add(usernameLabel);
        formPanel.add(usernameField);
        formPanel.add(passwordLabel);
        formPanel.add(passwordField);
        formPanel.add(roleLabel);
        formPanel.add(roleCombo);
        formPanel.add(rankLabel);
        formPanel.add(rankField);
        formPanel.add(new JLabel());
        formPanel.add(new JLabel());
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        buttonPanel.setBackground(UIHelper.PRIMARY_COLOR);
        
        JButton saveBtn = UIHelper.createSuccessButton("💾 Save");
        saveBtn.setPreferredSize(new Dimension(130, 40));
        saveBtn.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());
            String role = (String) roleCombo.getSelectedItem();
            String rank = rankField.getText().trim();
            
            if (validateInputs(dialog, username, password, rank)) {
                User newUser = new User(username, password, role, rank);
                if (userDAO.createUser(newUser)) {
                    UIHelper.showInfoDialog(dialog, "User created successfully!", "Success");
                    AuditLogger.logActivity(currentUser.getUserId(), currentUser.getUsername(),
                        "USER_CREATED", "Created user: " + username, "127.0.0.1", true);
                    loadUsers();
                    dialog.dispose();
                } else {
                    UIHelper.showErrorDialog(dialog, "Failed to create user. Username may already exist.", "Error");
                }
            }
        });
        
        JButton cancelBtn = UIHelper.createDangerButton("✖️ Cancel");
        cancelBtn.setPreferredSize(new Dimension(130, 40));
        cancelBtn.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        dialog.add(mainPanel);
        dialog.setVisible(true);
    }
    
    // ============ EDIT USER DIALOG ============
    
    private void showEditUserDialog() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow == -1) {
            UIHelper.showWarningDialog(this, "Please select a user to edit.", "No Selection");
            return;
        }
        
        int userId = (int) tableModel.getValueAt(selectedRow, 0);
        User user = userDAO.getUserById(userId);
        
        if (user == null) {
            UIHelper.showErrorDialog(this, "User not found.", "Error");
            return;
        }
        
        JDialog dialog = new JDialog(this, "Edit User: " + user.getUsername(), true);
        dialog.setSize(550, 480);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(UIHelper.BACKGROUND_COLOR);
        
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(UIHelper.BACKGROUND_COLOR);
        
        // Header
        JPanel headerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(UIHelper.PRIMARY_COLOR);
                g2.fillRect(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };
        headerPanel.setOpaque(false);
        headerPanel.setPreferredSize(new Dimension(550, 70));
        JLabel headerLabel = UIHelper.createStyledLabel(
            "Edit User",
            UIHelper.SUBHEADER_FONT,
            UIHelper.SECONDARY_COLOR
        );
        headerPanel.add(headerLabel);
        
        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 15, 20));
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        formPanel.setBackground(UIHelper.BACKGROUND_COLOR);
        
        // Username label (read-only)
        JLabel usernameLabel = UIHelper.createStyledLabel("Username:", UIHelper.NORMAL_FONT, UIHelper.TEXT_PRIMARY);
        JLabel usernameValue = UIHelper.createStyledLabel(user.getUsername(), UIHelper.NORMAL_FONT, UIHelper.SECONDARY_COLOR);
        
        // Role combo
        JLabel roleLabel = UIHelper.createStyledLabel("Role:", UIHelper.NORMAL_FONT, UIHelper.TEXT_PRIMARY);
        String[] roles = {"Soldier", "Officer", "Commander", "Admin"};
        JComboBox<String> roleCombo = UIHelper.createStyledComboBox(roles);
        roleCombo.setSelectedItem(user.getRole());
        roleCombo.setPreferredSize(new Dimension(200, 40));
        
        // Rank field
        JLabel rankLabel = UIHelper.createStyledLabel("Rank:", UIHelper.NORMAL_FONT, UIHelper.TEXT_PRIMARY);
        JTextField rankField = UIHelper.createStyledTextField();
        rankField.setText(user.getRank());
        rankField.setPreferredSize(new Dimension(200, 40));
        
        // Status combo
        JLabel statusLabel = UIHelper.createStyledLabel("Status:", UIHelper.NORMAL_FONT, UIHelper.TEXT_PRIMARY);
        String[] statuses = {"Active", "Inactive"};
        JComboBox<String> statusCombo = UIHelper.createStyledComboBox(statuses);
        statusCombo.setSelectedItem(user.isActive() ? "Active" : "Inactive");
        statusCombo.setPreferredSize(new Dimension(200, 40));
        
        formPanel.add(usernameLabel);
        formPanel.add(usernameValue);
        formPanel.add(roleLabel);
        formPanel.add(roleCombo);
        formPanel.add(rankLabel);
        formPanel.add(rankField);
        formPanel.add(statusLabel);
        formPanel.add(statusCombo);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        buttonPanel.setBackground(UIHelper.PRIMARY_COLOR);
        
        JButton saveBtn = UIHelper.createSuccessButton("💾 Save");
        saveBtn.setPreferredSize(new Dimension(130, 40));
        saveBtn.addActionListener(e -> {
            user.setRole((String) roleCombo.getSelectedItem());
            user.setRank(rankField.getText().trim());
            user.setActive(statusCombo.getSelectedItem().equals("Active"));
            
            if (userDAO.updateUser(user)) {
                UIHelper.showInfoDialog(dialog, "User updated successfully!", "Success");
                AuditLogger.logActivity(currentUser.getUserId(), currentUser.getUsername(),
                    "USER_UPDATED", "Updated user: " + user.getUsername(), "127.0.0.1", true);
                loadUsers();
                dialog.dispose();
            } else {
                UIHelper.showErrorDialog(dialog, "Failed to update user.", "Error");
            }
        });
        
        JButton cancelBtn = UIHelper.createDangerButton("✖️ Cancel");
        cancelBtn.setPreferredSize(new Dimension(130, 40));
        cancelBtn.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        dialog.add(mainPanel);
        dialog.setVisible(true);
    }
    
    // ============ DEACTIVATE USER ============
    
    private void deactivateUser() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow == -1) {
            UIHelper.showWarningDialog(this, "Please select a user to deactivate.", "No Selection");
            return;
        }
        
        int userId = (int) tableModel.getValueAt(selectedRow, 0);
        String username = (String) tableModel.getValueAt(selectedRow, 1);
        
        // Security check
        if (userId == currentUser.getUserId()) {
            UIHelper.showErrorDialog(this, "Security Restriction\n\nYou cannot deactivate your own account.", "Invalid Operation");
            return;
        }
        
        if (UIHelper.showConfirmDialog(this,
            "Deactivate User\n\n" +
            "Username: " + username + "\n\n" +
            "This will prevent the user from logging in.\n\n" +
            "Proceed?", "Confirm Deactivation")) {
            
            if (userDAO.deleteUser(userId)) {
                UIHelper.showInfoDialog(this, "User deactivated successfully.", "Success");
                AuditLogger.logActivity(currentUser.getUserId(), currentUser.getUsername(),
                    "USER_DEACTIVATED", "Deactivated user: " + username, "127.0.0.1", true);
                loadUsers();
            } else {
                UIHelper.showErrorDialog(this, "Failed to deactivate user.", "Error");
            }
        }
    }
    
    // ============ VALIDATION ============
    
    private boolean validateInputs(Component parent, String username, String password, String rank) {
        if (username.isEmpty() || password.isEmpty() || rank.isEmpty()) {
            UIHelper.showWarningDialog(parent, "All fields are required.", "Validation Error");
            return false;
        }
        
        if (username.length() < 3) {
            UIHelper.showWarningDialog(parent, "Username must be at least 3 characters.", "Validation Error");
            return false;
        }
        
        if (password.length() < 6) {
            UIHelper.showWarningDialog(parent, "Password must be at least 6 characters.", "Validation Error");
            return false;
        }
        
        return true;
    }
}