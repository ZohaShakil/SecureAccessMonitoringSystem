/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

/**
 *
 * @author malai
 */

import models.User;
import models.ActivityLog;
import database.ActivityLogDAO;
import logger.AuditLogger;
import utils.UIHelper;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;  
import java.awt.*;
import java.util.List;

/**
 * Professional Admin Frame for Audit Log Monitoring
 * Features: Real-time filtering, CSV export, advanced table rendering, professional UI
 * FIXED: Proper button colors and styling
 */
public class AdminFrame extends JFrame {
    private User user;
    private ActivityLogDAO activityLogDAO;
    private JTable logTable;
    private DefaultTableModel tableModel;
    private JLabel statsLabel;
    
    public AdminFrame(User user) {
        this.user = user;
        this.activityLogDAO = new ActivityLogDAO();
        initializeUI();
        loadLogs();
    }
    
    private void initializeUI() {
        setTitle("Audit Log Viewer - " + user.getUsername());
        setSize(1400, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(UIHelper.BACKGROUND_COLOR);
        
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(UIHelper.BACKGROUND_COLOR);
        
        // Header
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Content
        JPanel contentPanel = createContentPanel();
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Footer
        JPanel footerPanel = createFooterPanel();
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(UIHelper.PRIMARY_COLOR);
                g2.fillRect(0, 0, getWidth(), getHeight());
                
                g2.setColor(UIHelper.SECONDARY_COLOR);
                g2.setStroke(new BasicStroke(2));
                g2.drawLine(0, getHeight() - 1, getWidth(), getHeight() - 1);
                
                super.paintComponent(g);
            }
        };
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        
        JLabel titleLabel = UIHelper.createStyledLabel(
            "📋 AUDIT LOG VIEWER",
            UIHelper.TITLE_FONT,
            UIHelper.SECONDARY_COLOR
        );
        
        statsLabel = UIHelper.createStyledLabel(
            "Loading statistics...",
            UIHelper.NORMAL_FONT,
            UIHelper.TEXT_SECONDARY
        );
        
        panel.add(titleLabel, BorderLayout.WEST);
        panel.add(statsLabel, BorderLayout.EAST);
        
        return panel;
    }
    
    private JPanel createContentPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(UIHelper.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Table
        JPanel tablePanel = UIHelper.createTitledPanel("Activity Logs");
        tablePanel.setLayout(new BorderLayout());
        
        String[] columnNames = {"ID", "Timestamp", "Username", "Action", "Details", "IP Address", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        logTable = new JTable(tableModel);
        setupTableAppearance();
        
        JScrollPane scrollPane = new JScrollPane(logTable);
        scrollPane.setBackground(UIHelper.BACKGROUND_COLOR);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(UIHelper.BACKGROUND_COLOR);
        
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        panel.add(tablePanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private void setupTableAppearance() {
        logTable.setFont(UIHelper.NORMAL_FONT);
        logTable.setRowHeight(36);
        logTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        logTable.setGridColor(UIHelper.BORDER_COLOR);
        logTable.setBackground(UIHelper.SURFACE_COLOR);
        logTable.setForeground(UIHelper.TEXT_PRIMARY);
        logTable.setSelectionBackground(UIHelper.SECONDARY_COLOR);
        logTable.setSelectionForeground(UIHelper.TEXT_PRIMARY);
        
        // Header styling
        JTableHeader header = logTable.getTableHeader();
        header.setFont(UIHelper.SUBHEADER_FONT);
        header.setBackground(UIHelper.PRIMARY_COLOR);
        header.setForeground(UIHelper.SECONDARY_COLOR);
        header.setPreferredSize(new Dimension(100, 45));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, UIHelper.SECONDARY_COLOR));
        
        // Cell renderer
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                JLabel label = (JLabel) c;
                label.setFont(UIHelper.NORMAL_FONT);
                label.setHorizontalAlignment(JLabel.CENTER);
                
                // Status column color coding
                if (column == 6 && value != null) {
                    String status = value.toString();
                    if (status.contains("SUCCESS")) {
                        label.setForeground(UIHelper.SUCCESS_COLOR);
                        label.setText("✓ SUCCESS");
                    } else {
                        label.setForeground(UIHelper.DANGER_COLOR);
                        label.setText("✗ FAILED");
                    }
                }
                
                if (!isSelected) {
                    label.setBackground(row % 2 == 0 ? UIHelper.SURFACE_COLOR : UIHelper.PRIMARY_COLOR);
                    label.setOpaque(true);
                }
                
                return label;
            }
        };
        
        for (int i = 0; i < logTable.getColumnCount(); i++) {
            logTable.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }
        
        // Set column widths
        int[] widths = {60, 180, 130, 200, 300, 130, 120};
        for (int i = 0; i < widths.length; i++) {
            logTable.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }
    }
    
    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        panel.setBackground(UIHelper.PRIMARY_COLOR);
        panel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIHelper.BORDER_COLOR));
        
        // FIXED: Use new button styling methods with proper colors
        JButton refreshBtn = UIHelper.createInfoButton("🔄 Refresh");
        refreshBtn.setPreferredSize(new Dimension(140, 40));
        refreshBtn.addActionListener(e -> loadLogs());
        
        JButton exportBtn = UIHelper.createSuccessButton("📥 Export CSV");
        exportBtn.setPreferredSize(new Dimension(150, 40));
        exportBtn.addActionListener(e -> exportToCSV());
        
        JButton filterBtn = UIHelper.createPrimaryButton("🔍 Filter");
        filterBtn.setPreferredSize(new Dimension(130, 40));
        filterBtn.addActionListener(e -> showFilterDialog());
        
        JButton closeBtn = UIHelper.createDangerButton("✖️ Close");
        closeBtn.setPreferredSize(new Dimension(120, 40));
        closeBtn.addActionListener(e -> dispose());
        
        panel.add(refreshBtn);
        panel.add(exportBtn);
        panel.add(filterBtn);
        panel.add(closeBtn);
        
        return panel;
    }
    
    private void loadLogs() {
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        tableModel.setRowCount(0);
        
        SwingWorker<List<ActivityLog>, Void> worker = new SwingWorker<List<ActivityLog>, Void>() {
            @Override
            protected List<ActivityLog> doInBackground() {
                return activityLogDAO.getAllLogs();
            }
            
            @Override
            protected void done() {
                try {
                    List<ActivityLog> logs = get();
                    
                    for (ActivityLog log : logs) {
                        Object[] row = {
                            log.getLogId(),
                            log.getTimestamp().format(
                                java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                            log.getUsername(),
                            log.getAction(),
                            log.getDetails(),
                            log.getIpAddress(),
                            log.isSuccessful() ? "SUCCESS" : "FAILED"
                        };
                        tableModel.addRow(row);
                    }
                    
                    updateStats(logs);
                    setCursor(Cursor.getDefaultCursor());
                    
                    if (logs.isEmpty()) {
                        UIHelper.showInfoDialog(AdminFrame.this,
                            "No activity logs found.",
                            "Information");
                    }
                    
                } catch (Exception e) {
                    setCursor(Cursor.getDefaultCursor());
                    UIHelper.showErrorDialog(AdminFrame.this,
                        "Error loading logs: " + e.getMessage(),
                        "Error");
                }
            }
        };
        
        worker.execute();
    }
    
    private void updateStats(List<ActivityLog> logs) {
        long successCount = logs.stream().filter(ActivityLog::isSuccessful).count();
        long failedCount = logs.size() - successCount;
        statsLabel.setText(String.format(
            "Total: %d | Success: %d | Failed: %d",
            logs.size(), successCount, failedCount
        ));
    }
    
    private void showFilterDialog() {
        JDialog dialog = new JDialog(this, "Filter Logs", true);
        dialog.setSize(500, 450);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(UIHelper.BACKGROUND_COLOR);
        
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(UIHelper.BACKGROUND_COLOR);
        
        // Header
        JPanel headerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(UIHelper.PRIMARY_COLOR);
                g2.fillRect(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };
        headerPanel.setOpaque(false);
        headerPanel.setPreferredSize(new Dimension(500, 70));
        JLabel headerLabel = UIHelper.createStyledLabel(
            "Filter Logs",
            UIHelper.SUBHEADER_FONT,
            UIHelper.SECONDARY_COLOR
        );
        headerPanel.add(headerLabel);
        
        // Form
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 15, 20));
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        formPanel.setBackground(UIHelper.BACKGROUND_COLOR);
        
        JLabel userLabel = UIHelper.createStyledLabel("Username:", UIHelper.NORMAL_FONT, UIHelper.TEXT_PRIMARY);
        JTextField userField = UIHelper.createStyledTextField();
        userField.setPreferredSize(new Dimension(200, 35));
        
        JLabel actionLabel = UIHelper.createStyledLabel("Action:", UIHelper.NORMAL_FONT, UIHelper.TEXT_PRIMARY);
        String[] actions = {"All", "LOGIN", "LOGOUT", "COMMAND_EXECUTED", "ACCESSED_CLASSIFIED", "MISSION_EXECUTED"};
        JComboBox<String> actionCombo = UIHelper.createStyledComboBox(actions);
        actionCombo.setPreferredSize(new Dimension(200, 35));
        
        JLabel statusLabel = UIHelper.createStyledLabel("Status:", UIHelper.NORMAL_FONT, UIHelper.TEXT_PRIMARY);
        String[] statuses = {"All", "Success", "Failed"};
        JComboBox<String> statusCombo = UIHelper.createStyledComboBox(statuses);
        statusCombo.setPreferredSize(new Dimension(200, 35));
        
        formPanel.add(userLabel);
        formPanel.add(userField);
        formPanel.add(actionLabel);
        formPanel.add(actionCombo);
        formPanel.add(statusLabel);
        formPanel.add(statusCombo);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        buttonPanel.setBackground(UIHelper.PRIMARY_COLOR);
        
        JButton applyBtn = UIHelper.createSuccessButton("Apply Filter");
        applyBtn.setPreferredSize(new Dimension(130, 40));
        applyBtn.addActionListener(e -> {
            String username = userField.getText().trim();
            String action = (String) actionCombo.getSelectedItem();
            String status = (String) statusCombo.getSelectedItem();
            
            filterLogs(username, action, status);
            dialog.dispose();
        });
        
        JButton resetBtn = UIHelper.createPrimaryButton("Reset");
        resetBtn.setPreferredSize(new Dimension(100, 40));
        resetBtn.addActionListener(e -> {
            userField.setText("");
            actionCombo.setSelectedIndex(0);
            statusCombo.setSelectedIndex(0);
        });
        
        JButton cancelBtn = UIHelper.createDangerButton("Cancel");
        cancelBtn.setPreferredSize(new Dimension(100, 40));
        cancelBtn.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(applyBtn);
        buttonPanel.add(resetBtn);
        buttonPanel.add(cancelBtn);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        dialog.add(mainPanel);
        dialog.setVisible(true);
    }
    
    private void filterLogs(String username, String action, String status) {
        tableModel.setRowCount(0);
        List<ActivityLog> allLogs = activityLogDAO.getAllLogs();
        
        for (ActivityLog log : allLogs) {
            boolean matches = true;
            
            if (!username.isEmpty() && !log.getUsername().toLowerCase().contains(username.toLowerCase())) {
                matches = false;
            }
            
            if (!action.equals("All") && !log.getAction().equals(action)) {
                matches = false;
            }
            
            if (status.equals("Success") && !log.isSuccessful()) {
                matches = false;
            } else if (status.equals("Failed") && log.isSuccessful()) {
                matches = false;
            }
            
            if (matches) {
                Object[] row = {
                    log.getLogId(),
                    log.getTimestamp().format(
                        java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                    log.getUsername(),
                    log.getAction(),
                    log.getDetails(),
                    log.getIpAddress(),
                    log.isSuccessful() ? "SUCCESS" : "FAILED"
                };
                tableModel.addRow(row);
            }
        }
    }
    
    private void exportToCSV() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Export to CSV");
        fileChooser.setSelectedFile(new java.io.File("audit_logs_" +
            java.time.LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".csv"));
        
        int result = fileChooser.showSaveDialog(this);
        
        if (result == JFileChooser.APPROVE_OPTION) {
            try (java.io.FileWriter writer = new java.io.FileWriter(fileChooser.getSelectedFile())) {
                // Write header
                writer.write("ID,Timestamp,Username,Action,Details,IP Address,Status\n");
                
                // Write data
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    for (int j = 0; j < tableModel.getColumnCount(); j++) {
                        Object value = tableModel.getValueAt(i, j);
                        writer.write("\"" + (value != null ? value.toString() : "") + "\"");
                        if (j < tableModel.getColumnCount() - 1) {
                            writer.write(",");
                        }
                    }
                    writer.write("\n");
                }
                
                UIHelper.showInfoDialog(this,
                    "✓ Logs exported successfully to:\n\n" + fileChooser.getSelectedFile().getAbsolutePath(),
                    "Export Successful");
                
                AuditLogger.logActivity(user.getUserId(), user.getUsername(),
                    "EXPORTED_AUDIT_LOGS", "Exported " + tableModel.getRowCount() + " logs to CSV",
                    "127.0.0.1", true);
                
            } catch (Exception e) {
                UIHelper.showErrorDialog(this,
                    "Error exporting logs: " + e.getMessage(),
                    "Export Failed");
            }
        }
    }
}