/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

/**
 *
 * @author malai
 */

import models.User;
import models.Alert;
import database.AlertDAO;
import logger.AuditLogger;
import utils.UIHelper;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;  
import java.awt.*;
import java.util.List;

/**
 * Professional Alert Viewer Frame for Security Monitoring
 * Features: Severity color coding, statistics cards, acknowledgment, filtering
 * FIXED: Proper button colors and styling
 */
public class AlertViewerFrame extends JFrame {
    private User user;
    private AlertDAO alertDAO;
    private JTable alertTable;
    private DefaultTableModel tableModel;
    private JLabel criticalLabel, highLabel, mediumLabel, lowLabel;
    
    public AlertViewerFrame(User user) {
        this.user = user;
        this.alertDAO = new AlertDAO();
        initializeUI();
        loadAlerts();
    }
    
    private void initializeUI() {
        setTitle("Security Alerts - " + user.getUsername());
        setSize(1400, 850);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(UIHelper.BACKGROUND_COLOR);
        
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(UIHelper.BACKGROUND_COLOR);
        
        // Header
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Content
        JPanel contentPanel = createContentPanel();
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Footer
        JPanel footerPanel = createFooterPanel();
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                
                GradientPaint gradient = new GradientPaint(
                    0, 0, UIHelper.DANGER_COLOR,
                    getWidth(), 0, UIHelper.WARNING_COLOR
                );
                g2.setPaint(gradient);
                g2.fillRect(0, 0, getWidth(), getHeight());
                
                super.paintComponent(g);
            }
        };
        panel.setOpaque(false);
        panel.setPreferredSize(new Dimension(1400, 90));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        
        JLabel titleLabel = UIHelper.createStyledLabel(
            "⚠️ SECURITY ALERTS MONITORING",
            UIHelper.TITLE_FONT,
            Color.WHITE
        );
        panel.add(titleLabel);
        
        return panel;
    }
    
    private JPanel createContentPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(UIHelper.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Statistics panel
        JPanel statsPanel = createStatisticsPanel();
        panel.add(statsPanel, BorderLayout.NORTH);
        
        // Table panel
        JPanel tablePanel = createTablePanel();
        panel.add(tablePanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createStatisticsPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 4, 15, 0));
        panel.setBackground(UIHelper.BACKGROUND_COLOR);
        panel.setPreferredSize(new Dimension(1400, 130));
        
        criticalLabel = createStatCard("CRITICAL", "0", UIHelper.DANGER_COLOR);
        highLabel = createStatCard("HIGH", "0", new Color(255, 140, 0));
        mediumLabel = createStatCard("MEDIUM", "0", UIHelper.WARNING_COLOR);
        lowLabel = createStatCard("LOW", "0", UIHelper.SUCCESS_COLOR);
        
        JPanel criticalPanel = createCardContainer(criticalLabel, UIHelper.DANGER_COLOR);
        JPanel highPanel = createCardContainer(highLabel, new Color(255, 140, 0));
        JPanel mediumPanel = createCardContainer(mediumLabel, UIHelper.WARNING_COLOR);
        JPanel lowPanel = createCardContainer(lowLabel, UIHelper.SUCCESS_COLOR);
        
        panel.add(criticalPanel);
        panel.add(highPanel);
        panel.add(mediumPanel);
        panel.add(lowPanel);
        
        return panel;
    }
    
    private JPanel createCardContainer(JLabel valueLabel, Color color) {
        JPanel card = new JPanel(new GridLayout(2, 1, 0, 8)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                g2.setColor(UIHelper.SURFACE_COLOR);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                
                g2.setColor(color);
                g2.setStroke(new BasicStroke(2.5f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(20, 15, 20, 15));
        
        // Extract label text from value label
        String labelText = valueLabel.getText();
        String[] parts = labelText.split("\n");
        
        JLabel titleLabel = UIHelper.createStyledLabel(
            parts[1] != null ? parts[1] : "LABEL",
            UIHelper.SUBHEADER_FONT,
            color
        );
        
        JLabel countLabel = UIHelper.createStyledLabel(
            parts[0],
            new Font("Segoe UI", Font.BOLD, 32),
            color
        );
        
        card.add(countLabel);
        card.add(titleLabel);
        
        return card;
    }
    
    private JLabel createStatCard(String label, String value, Color color) {
        return UIHelper.createStyledLabel(
            value + "\n" + label,
            UIHelper.NORMAL_FONT,
            color
        );
    }
    
    private JPanel createTablePanel() {
        JPanel panel = UIHelper.createTitledPanel("Alert History");
        panel.setLayout(new BorderLayout());
        
        String[] columnNames = {"ID", "Severity", "Timestamp", "Username", "Message", "Details", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        alertTable = new JTable(tableModel);
        setupTableAppearance();
        
        JScrollPane scrollPane = new JScrollPane(alertTable);
        scrollPane.setBackground(UIHelper.BACKGROUND_COLOR);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(UIHelper.BACKGROUND_COLOR);
        
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private void setupTableAppearance() {
        alertTable.setFont(UIHelper.NORMAL_FONT);
        alertTable.setRowHeight(38);
        alertTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        alertTable.setGridColor(UIHelper.BORDER_COLOR);
        alertTable.setBackground(UIHelper.SURFACE_COLOR);
        alertTable.setForeground(UIHelper.TEXT_PRIMARY);
        alertTable.setSelectionBackground(UIHelper.SECONDARY_COLOR);
        
        // Header styling
        JTableHeader header = alertTable.getTableHeader();
        header.setFont(UIHelper.SUBHEADER_FONT);
        header.setBackground(UIHelper.PRIMARY_COLOR);
        header.setForeground(UIHelper.SECONDARY_COLOR);
        header.setPreferredSize(new Dimension(100, 45));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, UIHelper.SECONDARY_COLOR));
        
        // Custom cell renderer with severity color coding
        alertTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                JLabel label = (JLabel) c;
                label.setFont(UIHelper.NORMAL_FONT);
                label.setHorizontalAlignment(JLabel.CENTER);
                
                if (!isSelected) {
                    // Color code by severity
                    String severity = (String) table.getValueAt(row, 1);
                    switch (severity) {
                        case "CRITICAL":
                            label.setBackground(new Color(255, 230, 230));
                            label.setForeground(UIHelper.DANGER_COLOR);
                            break;
                        case "HIGH":
                            label.setBackground(new Color(255, 240, 220));
                            label.setForeground(new Color(255, 140, 0));
                            break;
                        case "MEDIUM":
                            label.setBackground(new Color(255, 250, 230));
                            label.setForeground(UIHelper.WARNING_COLOR);
                            break;
                        case "LOW":
                            label.setBackground(new Color(230, 255, 230));
                            label.setForeground(UIHelper.SUCCESS_COLOR);
                            break;
                        default:
                            label.setBackground(UIHelper.SURFACE_COLOR);
                            label.setForeground(UIHelper.TEXT_PRIMARY);
                    }
                    label.setOpaque(true);
                }
                
                // Format severity column
                if (column == 1 && value != null) {
                    String severity = value.toString();
                    switch (severity) {
                        case "CRITICAL": label.setText("🔴 CRITICAL"); break;
                        case "HIGH": label.setText("🟠 HIGH"); break;
                        case "MEDIUM": label.setText("🟡 MEDIUM"); break;
                        case "LOW": label.setText("🟢 LOW"); break;
                    }
                }
                
                // Format status column
                if (column == 6 && value != null) {
                    String status = value.toString();
                    if (status.contains("Acknowledged")) {
                        label.setText("✓ Acknowledged");
                    } else {
                        label.setText("⚠️ Pending");
                    }
                }
                
                return label;
            }
        });
        
        // Set column widths
        int[] widths = {60, 110, 170, 130, 300, 400, 140};
        for (int i = 0; i < widths.length; i++) {
            alertTable.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }
    }
    
    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        panel.setBackground(UIHelper.PRIMARY_COLOR);
        panel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIHelper.BORDER_COLOR));
        
        // FIXED: Use new button styling methods with proper colors
        JButton refreshBtn = UIHelper.createInfoButton("🔄 Refresh");
        refreshBtn.setPreferredSize(new Dimension(140, 40));
        refreshBtn.addActionListener(e -> loadAlerts());
        
        JButton acknowledgeBtn = UIHelper.createSuccessButton("✓ Acknowledge");
        acknowledgeBtn.setPreferredSize(new Dimension(160, 40));
        acknowledgeBtn.addActionListener(e -> acknowledgeSelected());
        
        JButton filterBtn = UIHelper.createPrimaryButton("🔍 Filter");
        filterBtn.setPreferredSize(new Dimension(130, 40));
        filterBtn.addActionListener(e -> showFilterDialog());
        
        JButton closeBtn = UIHelper.createDangerButton("✖️ Close");
        closeBtn.setPreferredSize(new Dimension(120, 40));
        closeBtn.addActionListener(e -> dispose());
        
        panel.add(refreshBtn);
        panel.add(acknowledgeBtn);
        panel.add(filterBtn);
        panel.add(closeBtn);
        
        return panel;
    }
    
    private void loadAlerts() {
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        tableModel.setRowCount(0);
        
        SwingWorker<List<Alert>, Void> worker = new SwingWorker<List<Alert>, Void>() {
            @Override
            protected List<Alert> doInBackground() {
                return alertDAO.getAllAlerts();
            }
            
            @Override
            protected void done() {
                try {
                    List<Alert> alerts = get();
                    
                    for (Alert alert : alerts) {
                        Object[] row = {
                            alert.getAlertId(),
                            alert.getSeverity().toString(),
                            alert.getTimestamp().format(
                                java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                            alert.getUsername() != null ? alert.getUsername() : "SYSTEM",
                            alert.getMessage(),
                            alert.getDetails() != null ? alert.getDetails() : "",
                            alert.isAcknowledged() ? "Acknowledged" : "Pending"
                        };
                        tableModel.addRow(row);
                    }
                    
                    updateStatistics(alerts);
                    setCursor(Cursor.getDefaultCursor());
                    
                } catch (Exception e) {
                    setCursor(Cursor.getDefaultCursor());
                    UIHelper.showErrorDialog(AlertViewerFrame.this,
                        "Error loading alerts: " + e.getMessage(),
                        "Error");
                }
            }
        };
        
        worker.execute();
    }
    
    private void updateStatistics(List<Alert> alerts) {
        long critical = alerts.stream().filter(a -> a.getSeverity() == Alert.Severity.CRITICAL).count();
        long high = alerts.stream().filter(a -> a.getSeverity() == Alert.Severity.HIGH).count();
        long medium = alerts.stream().filter(a -> a.getSeverity() == Alert.Severity.MEDIUM).count();
        long low = alerts.stream().filter(a -> a.getSeverity() == Alert.Severity.LOW).count();
        
        criticalLabel.setText(critical + "\nCRITICAL");
        highLabel.setText(high + "\nHIGH");
        mediumLabel.setText(medium + "\nMEDIUM");
        lowLabel.setText(low + "\nLOW");
    }
    
    private void acknowledgeSelected() {
        int selectedRow = alertTable.getSelectedRow();
        
        if (selectedRow == -1) {
            UIHelper.showWarningDialog(this,
                "Please select an alert to acknowledge.",
                "No Selection");
            return;
        }
        
        int alertId = (int) tableModel.getValueAt(selectedRow, 0);
        String status = (String) tableModel.getValueAt(selectedRow, 6);
        
        if (status.contains("Acknowledged")) {
            UIHelper.showInfoDialog(this,
                "This alert has already been acknowledged.",
                "Already Acknowledged");
            return;
        }
        
        boolean success = alertDAO.acknowledgeAlert(alertId);
        
        if (success) {
            UIHelper.showInfoDialog(this,
                "✓ Alert #" + alertId + " acknowledged successfully\n\n" +
                "Acknowledged by: " + user.getUsername() + "\n" +
                "Time: " + java.time.LocalDateTime.now().format(
                    java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                "Success");
            
            AuditLogger.logActivity(user.getUserId(), user.getUsername(),
                "ACKNOWLEDGED_ALERT", "Alert ID: " + alertId, "127.0.0.1", true);
            
            loadAlerts();
        } else {
            UIHelper.showErrorDialog(this,
                "Failed to acknowledge alert.",
                "Error");
        }
    }
    
    private void showFilterDialog() {
        String[] severities = {"All", "CRITICAL", "HIGH", "MEDIUM", "LOW"};
        String selected = (String) JOptionPane.showInputDialog(
            this,
            "Select severity level to filter alerts:",
            "Filter Alerts",
            JOptionPane.QUESTION_MESSAGE,
            null,
            severities,
            severities[0]
        );
        
        if (selected != null) {
            filterBySeverity(selected);
        }
    }
    
    private void filterBySeverity(String severity) {
        tableModel.setRowCount(0);
        List<Alert> allAlerts = alertDAO.getAllAlerts();
        
        for (Alert alert : allAlerts) {
            if (severity.equals("All") || alert.getSeverity().toString().equals(severity)) {
                Object[] row = {
                    alert.getAlertId(),
                    alert.getSeverity().toString(),
                    alert.getTimestamp().format(
                        java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                    alert.getUsername() != null ? alert.getUsername() : "SYSTEM",
                    alert.getMessage(),
                    alert.getDetails() != null ? alert.getDetails() : "",
                    alert.isAcknowledged() ? "Acknowledged" : "Pending"
                };
                tableModel.addRow(row);
            }
        }
    }
}