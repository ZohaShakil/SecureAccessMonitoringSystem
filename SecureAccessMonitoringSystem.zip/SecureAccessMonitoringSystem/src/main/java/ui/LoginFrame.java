package ui;

import models.User;
import database.UserDAO;
import security.SessionMonitor;
import security.AnomalyDetector;
import logger.AuditLogger;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private UserDAO userDAO;
    private int failedAttempts = 0;
    private static final int MAX_FAILED_ATTEMPTS = 5;
    
    public LoginFrame() {
        userDAO = new UserDAO();
        setupUI();
    }
    
    private void setupUI() {
        setTitle("Defence Operations - Secure Access");
        setSize(600, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Main panel with dark background
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(new Color(15, 23, 42));
        
        // Add spacing at top
        mainPanel.add(Box.createVerticalStrut(80));
        
        // Title
        JLabel titleLabel = new JLabel("DEFENCE OPERATIONS");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(new Color(0, 150, 215));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        
        mainPanel.add(Box.createVerticalStrut(10));
        
        // Subtitle
        JLabel subtitleLabel = new JLabel("Secure Access Monitoring System");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        subtitleLabel.setForeground(new Color(148, 163, 184));
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(subtitleLabel);
        
        mainPanel.add(Box.createVerticalStrut(60));
        
        // Form Panel - CENTERED
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBackground(new Color(30, 41, 59));
        formPanel.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
        formPanel.setMaximumSize(new Dimension(500, 400));
        formPanel.setAlignmentX(Component.CENTER_ALIGNMENT);  // CENTER IT!
        
        // Username Label
        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        usernameLabel.setForeground(Color.WHITE);
        usernameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(usernameLabel);
        
        formPanel.add(Box.createVerticalStrut(8));
        
        // USERNAME FIELD - SIMPLE & VISIBLE
        usernameField = new JTextField(20);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 18));
        usernameField.setBackground(Color.WHITE);  // WHITE BACKGROUND
        usernameField.setForeground(Color.BLACK);  // BLACK TEXT
        usernameField.setCaretColor(Color.BLACK);
        usernameField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.GRAY, 1),
            BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        usernameField.setMaximumSize(new Dimension(450, 50));
        usernameField.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(usernameField);
        
        formPanel.add(Box.createVerticalStrut(25));
        
        // Password Label
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(passwordLabel);
        
        formPanel.add(Box.createVerticalStrut(8));
        
        // PASSWORD FIELD - SIMPLE & VISIBLE
        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 18));
        passwordField.setBackground(Color.WHITE);  // WHITE BACKGROUND
        passwordField.setForeground(Color.BLACK);  // BLACK DOTS
        passwordField.setCaretColor(Color.BLACK);
        passwordField.setEchoChar('●');  // BIG BLACK DOT
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.GRAY, 1),
            BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        passwordField.setMaximumSize(new Dimension(450, 50));
        passwordField.setAlignmentX(Component.LEFT_ALIGNMENT);
        passwordField.addActionListener(e -> handleLogin());
        formPanel.add(passwordField);
        
        formPanel.add(Box.createVerticalStrut(35));
        
        // LOGIN BUTTON
        loginButton = new JButton("LOGIN");
        loginButton.setFont(new Font("Arial", Font.BOLD, 16));
        loginButton.setBackground(new Color(0, 150, 215));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.setBorderPainted(false);
        loginButton.setMaximumSize(new Dimension(450, 50));
        loginButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginButton.addActionListener(e -> handleLogin());
        formPanel.add(loginButton);
        
        mainPanel.add(formPanel);
        mainPanel.add(Box.createVerticalStrut(40));
        
        // Footer
        JLabel footerLabel = new JLabel("© 2025 Defence Operations - All Rights Reserved");
        footerLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        footerLabel.setForeground(new Color(148, 163, 184));
        footerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(footerLabel);
        
        add(mainPanel);
    }
    
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter both username and password", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (failedAttempts >= MAX_FAILED_ATTEMPTS) {
            JOptionPane.showMessageDialog(this, 
                "Maximum failed attempts exceeded. System locked.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            loginButton.setEnabled(false);
            return;
        }
        
        loginButton.setEnabled(false);
        loginButton.setText("AUTHENTICATING...");
        
        SwingWorker<User, Void> worker = new SwingWorker<User, Void>() {
            @Override
            protected User doInBackground() {
                try {
                    Thread.sleep(500);
                    return userDAO.authenticate(username, password);
                } catch (InterruptedException e) {
                    return null;
                }
            }
            
            @Override
            protected void done() {
                try {
                    User user = get();
                    
                    if (user != null && user.isActive()) {
                        user.setLoggedIn(true);
                        String sessionId = SessionMonitor.startSession(user, "127.0.0.1");
                        user.setSessionId(sessionId);
                        
                        AnomalyDetector.recordSuccessfulLogin(user.getUsername());
                        AuditLogger.logActivity(
                            user.getUserId(), user.getUsername(), "LOGIN_SUCCESSFUL",
                            "User logged in successfully", "127.0.0.1", true
                        );
                        
                        loginButton.setText("SUCCESS ✓");
                        loginButton.setBackground(new Color(34, 197, 94));
                        
                        Timer timer = new Timer(1000, evt -> {
                            new DashboardFrame(user, sessionId).setVisible(true);
                            dispose();
                        });
                        timer.setRepeats(false);
                        timer.start();
                        
                        failedAttempts = 0;
                    } else {
                        failedAttempts++;
                        
                        AnomalyDetector.recordFailedLogin(username);
                        AuditLogger.logActivity(
                            0, username, "LOGIN_FAILED",
                            "Invalid credentials - Attempt " + failedAttempts + "/" + MAX_FAILED_ATTEMPTS,
                            "127.0.0.1", false
                        );
                        
                        loginButton.setText("FAILED");
                        loginButton.setBackground(new Color(239, 68, 68));
                        
                        JOptionPane.showMessageDialog(LoginFrame.this, 
                            "Invalid credentials (" + failedAttempts + "/" + MAX_FAILED_ATTEMPTS + ")", 
                            "Login Failed", 
                            JOptionPane.ERROR_MESSAGE);
                        
                        if (failedAttempts >= MAX_FAILED_ATTEMPTS) {
                            JOptionPane.showMessageDialog(LoginFrame.this,
                                "⚠️ SECURITY ALERT\n\n" +
                                "Maximum failed login attempts exceeded.\n" +
                                "System access is temporarily locked.\n\n" +
                                "Please contact your administrator.",
                                "Account Locked",
                                JOptionPane.WARNING_MESSAGE);
                        }
                        
                        passwordField.setText("");
                        usernameField.requestFocus();
                        
                        Timer timer = new Timer(1500, evt -> {
                            loginButton.setEnabled(true);
                            loginButton.setBackground(new Color(0, 150, 215));
                            loginButton.setText("LOGIN");
                        });
                        timer.setRepeats(false);
                        timer.start();
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(LoginFrame.this, 
                        "System error: " + e.getMessage(), 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                    
                    loginButton.setEnabled(true);
                    loginButton.setBackground(new Color(0, 150, 215));
                    loginButton.setText("LOGIN");
                }
            }
        };
        
        worker.execute();
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
