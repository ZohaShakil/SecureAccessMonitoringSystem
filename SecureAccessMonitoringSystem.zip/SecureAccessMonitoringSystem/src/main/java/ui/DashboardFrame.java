package ui;

/**
 *
 * @author malai
 */

import models.User;
import security.*;
import logger.AuditLogger;
import utils.UIHelper;

import javax.swing.*;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Professional Dashboard Frame with Real-Time Monitoring
 * Features: Role-based access, Real-time stats, Operation tracking, Audit monitoring
 * FIXED: Removed problematic setForegroundAt(0) that was causing IndexOutOfBoundsException
 */
public class DashboardFrame extends JFrame {
    private User user;
    private String sessionId;
    private CommandValidator validator;
    private RBACManager rbac;
    private JLabel timeLabel;
    private JLabel sessionStatusLabel;
    private JTabbedPane tabbedPane;
    private Timer updateTimer;
    
    public DashboardFrame(User user, String sessionId) {
        this.user = user;
        this.sessionId = sessionId;
        this.rbac = new RBACManager();
        this.validator = new CommandValidator(rbac);
        
        initializeUI();
        startLiveUpdates();
    }
    
    private void initializeUI() {
        setTitle("Defence Operations - Dashboard [" + user.getUsername() + " - " + user.getRank() + "]");
        setSize(1400, 900);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(UIHelper.BACKGROUND_COLOR);
        
        // Main container
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(UIHelper.BACKGROUND_COLOR);
        
        // Header
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Tabbed content area - WITH COLORED TABS
        tabbedPane = createTabbedContent();
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        
        // Footer
        JPanel footerPanel = createFooterPanel();
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
        
        // Window closing handler
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                handleLogout();
            }
        });
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(UIHelper.PRIMARY_COLOR);
                g2.fillRect(0, 0, getWidth(), getHeight());
                
                g2.setColor(UIHelper.SECONDARY_COLOR);
                g2.setStroke(new BasicStroke(2));
                g2.drawLine(0, getHeight() - 1, getWidth(), getHeight() - 1);
                
                super.paintComponent(g);
            }
        };
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        // Left: Title and user info
        JPanel leftPanel = new JPanel(new GridLayout(2, 1, 0, 5));
        leftPanel.setOpaque(false);
        
        JLabel titleLabel = UIHelper.createStyledLabel(
            "SECURE ACCESS MONITORING SYSTEM",
            UIHelper.TITLE_FONT,
            UIHelper.SECONDARY_COLOR
        );
        
        JLabel userInfoLabel = UIHelper.createStyledLabel(
            user.getUsername() + " | " + user.getRank() + " | Role: " + user.getRole(),
            UIHelper.SUBHEADER_FONT,
            UIHelper.TEXT_PRIMARY
        );
        
        leftPanel.add(titleLabel);
        leftPanel.add(userInfoLabel);
        
        // Right: Live status
        JPanel rightPanel = new JPanel(new GridLayout(1, 3, 15, 0));
        rightPanel.setOpaque(false);
        
        sessionStatusLabel = createStatusCard("SESSION STATUS", "Active", UIHelper.SUCCESS_COLOR);
        JLabel clearanceLabel = createStatusCard("CLEARANCE LEVEL", user.getRole(), UIHelper.SECONDARY_COLOR);
        timeLabel = createStatusCard("LOCAL TIME", getCurrentTime(), UIHelper.INFO_COLOR);
        
        rightPanel.add(sessionStatusLabel);
        rightPanel.add(clearanceLabel);
        rightPanel.add(timeLabel);
        
        panel.add(leftPanel, BorderLayout.WEST);
        panel.add(rightPanel, BorderLayout.EAST);
        
        return panel;
    }
    
    private JLabel createStatusCard(String title, String value, Color color) {
        JPanel cardPanel = new JPanel(new GridLayout(2, 1, 0, 3)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                g2.setColor(UIHelper.SURFACE_COLOR);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                
                g2.setColor(color);
                g2.setStroke(new BasicStroke(2));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                
                super.paintComponent(g);
            }
        };
        cardPanel.setOpaque(false);
        cardPanel.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        
        JLabel titleLabel = UIHelper.createStyledLabel(title, UIHelper.SMALL_FONT, UIHelper.TEXT_SECONDARY);
        JLabel valueLabel = UIHelper.createStyledLabel(value, UIHelper.SUBHEADER_FONT, color);
        
        cardPanel.add(titleLabel);
        cardPanel.add(valueLabel);
        
        return valueLabel;
    }
    
    private JTabbedPane createTabbedContent() {
        tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(UIHelper.BACKGROUND_COLOR);
        tabbedPane.setForeground(UIHelper.TEXT_PRIMARY);
        tabbedPane.setFont(UIHelper.NORMAL_FONT);
        
        // ============ CUSTOM TAB UI WITH COLORS ============
        tabbedPane.setUI(new BasicTabbedPaneUI() {
            @Override
            protected void paintTabBackground(Graphics g, int tabPlacement,
                    int tabIndex, int x, int y, int w, int h, boolean isSelected) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Tab colors based on index
                Color tabColor;
                switch (tabIndex) {
                    case 0: // Operations - BLUE
                        tabColor = isSelected ? UIHelper.SECONDARY_COLOR : UIHelper.PRIMARY_COLOR;
                        break;
                    case 1: // Security Status - GREEN
                        tabColor = isSelected ? UIHelper.SUCCESS_COLOR : UIHelper.PRIMARY_COLOR;
                        break;
                    case 2: // Administration - ORANGE/WARNING
                        tabColor = isSelected ? UIHelper.WARNING_COLOR : UIHelper.PRIMARY_COLOR;
                        break;
                    case 3: // Activity Logs - INFO BLUE
                        tabColor = isSelected ? UIHelper.INFO_COLOR : UIHelper.PRIMARY_COLOR;
                        break;
                    default:
                        tabColor = isSelected ? UIHelper.SECONDARY_COLOR : UIHelper.PRIMARY_COLOR;
                }
                
                g2.setColor(tabColor);
                g2.fillRect(x, y, w, h);
                
                // Border
                g2.setColor(UIHelper.BORDER_COLOR);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRect(x, y, w - 1, h - 1);
            }
            
            @Override
            protected void paintTabBorder(Graphics g, int tabPlacement,
                    int tabIndex, int x, int y, int w, int h, boolean isSelected) {
                // Already painted in paintTabBackground
            }
            
            @Override
            protected void paintContentBorderTopEdge(Graphics g, int tabPlacement,
                    int selectedIndex, int x, int y, int w, int h) {
                g.setColor(UIHelper.BORDER_COLOR);
                g.drawLine(x, y, x + w, y);
            }
        });
        
        // Operations Tab
        tabbedPane.addTab("⚡ Operations", createOperationsPanel());
        
        // Security Status Tab
        tabbedPane.addTab("🛡️ Security Status", createSecurityStatusPanel());
        
        // Admin Panel (if authorized)
        if (rbac.hasPermission(user, "VIEW_AUDIT_LOGS")) {
            tabbedPane.addTab("👤 Administration", createAdminPanel());
        }
        
        // Activity Logs Tab
        tabbedPane.addTab("📊 Activity Logs", createActivityPanel());
        
        return tabbedPane;
    }
    
    private JPanel createOperationsPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 15, 15));
        panel.setBackground(UIHelper.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Operations cards
        panel.add(createOperationCard(
            "📋 View Data",
            "Access operational data and intelligence",
            UIHelper.SECONDARY_COLOR,
            () -> {
                updateActivity();
                if (validator.validateAndExecute(user, "View Data")) {
                    showClassifiedData();
                } else {
                    UIHelper.showErrorDialog(this, "Access denied. Insufficient permissions.", "Unauthorized");
                }
            }
        ));
        
        panel.add(createOperationCard(
            "💻 Issue Command",
            "Transmit tactical commands to field units",
            UIHelper.INFO_COLOR,
            () -> {
                updateActivity();
                if (validator.validateAndExecute(user, "Issue Command")) {
                    issueCommand();
                } else {
                    UIHelper.showErrorDialog(this, "Access denied. Insufficient permissions.", "Unauthorized");
                }
            }
        ));
        
        panel.add(createOperationCard(
            "🔐 Access Classified",
            "View high-security classified information",
            UIHelper.WARNING_COLOR,
            () -> {
                updateActivity();
                if (validator.validateAndExecute(user, "Access Classified")) {
                    accessClassified();
                } else {
                    UIHelper.showErrorDialog(this, "Access denied. Insufficient permissions.", "Unauthorized");
                }
            }
        ));
        
        panel.add(createOperationCard(
            "🚀 Execute Mission",
            "Deploy active military operations (Restricted)",
            UIHelper.DANGER_COLOR,
            () -> {
                updateActivity();
                if (validator.validateAndExecute(user, "Execute Mission")) {
                    executeMission();
                } else {
                    UIHelper.showErrorDialog(this, "Access denied. Commander-level authorization required.", "Unauthorized");
                }
            }
        ));
        
        return panel;
    }
    
    private JPanel createOperationCard(String title, String description, Color color, Runnable action) {
        JPanel card = new JPanel(new GridLayout(3, 1, 0, 10)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                g2.setColor(UIHelper.SURFACE_COLOR);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                
                g2.setColor(color);
                g2.setStroke(new BasicStroke(2));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        JLabel titleLabel = UIHelper.createStyledLabel(title, UIHelper.SUBHEADER_FONT, color);
        JLabel descLabel = UIHelper.createStyledLabel(description, UIHelper.NORMAL_FONT, UIHelper.TEXT_SECONDARY);
        JButton actionBtn = UIHelper.createStyledButton("EXECUTE", color);
        actionBtn.addActionListener(e -> action.run());
        
        card.add(titleLabel);
        card.add(descLabel);
        card.add(actionBtn);
        
        return card;
    }
    
    private JPanel createSecurityStatusPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 15, 15));
        panel.setBackground(UIHelper.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Security metrics
        panel.add(UIHelper.createCardPanel("Active Sessions", String.valueOf(SessionMonitor.getActiveSessionCount()), UIHelper.SUCCESS_COLOR));
        panel.add(UIHelper.createCardPanel("Failed Login Attempts", "0", UIHelper.WARNING_COLOR));
        panel.add(UIHelper.createCardPanel("Threat Level", "MODERATE", UIHelper.WARNING_COLOR));
        panel.add(UIHelper.createCardPanel("Security Status", "🔒 SECURED", UIHelper.SUCCESS_COLOR));
        
        return panel;
    }
    
    private JPanel createAdminPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 15, 15));
        panel.setBackground(UIHelper.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JButton auditBtn = UIHelper.createPrimaryButton("📋 Audit Logs");
        auditBtn.setPreferredSize(new Dimension(150, 50));
        auditBtn.addActionListener(e -> {
            updateActivity();
            new AdminFrame(user).setVisible(true);
        });
        
        JButton sessionsBtn = UIHelper.createPrimaryButton("👥 Active Sessions");
        sessionsBtn.setPreferredSize(new Dimension(150, 50));
        sessionsBtn.addActionListener(e -> {
            updateActivity();
            new SessionViewerFrame(user).setVisible(true);
        });
        
        JButton alertsBtn = UIHelper.createDangerButton("⚠️ Security Alerts");
        alertsBtn.setPreferredSize(new Dimension(150, 50));
        alertsBtn.addActionListener(e -> {
            updateActivity();
            new AlertViewerFrame(user).setVisible(true);
        });
        
        JButton usersBtn = UIHelper.createPrimaryButton("👤 User Management");
        usersBtn.setPreferredSize(new Dimension(150, 50));
        usersBtn.addActionListener(e -> {
            updateActivity();
            if (rbac.hasPermission(user, "MANAGE_USERS")) {
                new UserManagementFrame(user).setVisible(true);
            } else {
                UIHelper.showErrorDialog(this, "Access denied. Admin privileges required.", "Unauthorized");
            }
        });
        
        panel.add(auditBtn);
        panel.add(sessionsBtn);
        panel.add(alertsBtn);
        panel.add(usersBtn);
        
        return panel;
    }
    
    private JPanel createActivityPanel() {
        JPanel panel = UIHelper.createTitledPanel("Recent Activity Log");
        panel.setLayout(new BorderLayout());
        
        JTextArea activityArea = UIHelper.createStyledTextArea();
        activityArea.setEditable(false);
        activityArea.setFont(UIHelper.MONO_FONT);
        
        java.util.List<String> recentLogs = AuditLogger.getRecentLogs(50);
        for (String log : recentLogs) {
            activityArea.append(log + "\n");
        }
        
        JScrollPane scrollPane = new JScrollPane(activityArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        return panel;
    }
    
    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 15));
        panel.setBackground(UIHelper.PRIMARY_COLOR);
        panel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIHelper.BORDER_COLOR));
        
        JLabel infoLabel = UIHelper.createStyledLabel(
            "Session ID: " + sessionId.substring(0, 8) + "...",
            UIHelper.SMALL_FONT,
            UIHelper.TEXT_SECONDARY
        );
        
        JButton logoutBtn = UIHelper.createDangerButton("🚪 Logout");
        logoutBtn.setPreferredSize(new Dimension(130, 40));
        logoutBtn.addActionListener(e -> handleLogout());
        
        panel.add(infoLabel);
        panel.add(logoutBtn);
        
        return panel;
    }
    
    // ============ OPERATION IMPLEMENTATIONS ============
    
    private void showClassifiedData() {
        String classifiedData = "═══════════════════════════════════════════════\n" +
                               "      CLASSIFIED OPERATIONAL DATA\n" +
                               "═══════════════════════════════════════════════\n\n" +
                               "Access Level: " + user.getRole() + "\n" +
                               "Clearance: " + user.getRank() + "\n" +
                               "Time: " + getCurrentTime() + "\n\n" +
                               "CURRENT OPERATIONS:\n" +
                               "─────────────────────────────────────────────────\n" +
                               "• Operation Nightfall - Status: ACTIVE\n" +
                               "  Personnel: 45 | Location: Sector 7\n" +
                               "  Commander: Maj. Richardson\n\n" +
                               "• Operation Shield - Status: STANDBY\n" +
                               "  Personnel: 30 | Location: Base Alpha\n" +
                               "  Commander: Capt. Morrison\n\n" +
                               "═══════════════════════════════════════════════\n" +
                               "    END OF CLASSIFIED DATA\n" +
                               "═══════════════════════════════════════════════";
        
        showInformationDialog("Classified Data", classifiedData);
        
        AuditLogger.logActivity(user.getUserId(), user.getUsername(),
            "VIEWED_CLASSIFIED_DATA", "Accessed operational data", "127.0.0.1", true);
    }
    
    private void issueCommand() {
        String[] commands = {
            "Deploy Unit Alpha to Sector 7",
            "Recall Unit Bravo to Base",
            "Initiate Patrol Route Delta",
            "Request Air Support",
            "Establish Security Checkpoint",
            "Activate Emergency Protocol"
        };
        
        String command = (String) JOptionPane.showInputDialog(
            this, "Select Command to Execute:", "Command Execution",
            JOptionPane.QUESTION_MESSAGE, null, commands, commands[0]
        );
        
        if (command != null) {
            showProgressDialog("Command Execution", "Transmitting command...", () -> {
                AuditLogger.logActivity(user.getUserId(), user.getUsername(),
                    "COMMAND_EXECUTED", command, "127.0.0.1", true);
                
                String result = "╔════════════════════════════════════════╗\n" +
                              "      COMMAND TRANSMISSION REPORT\n" +
                              "╚════════════════════════════════════════╝\n\n" +
                              "Command: " + command + "\n" +
                              "Status: ✓ TRANSMITTED\n" +
                              "Issued By: " + user.getUsername() + "\n" +
                              "Timestamp: " + getCurrentTime() + "\n\n" +
                              "This action has been logged.";
                
                showInformationDialog("Command Confirmation", result);
            });
        }
    }
    
    private void accessClassified() {
        String[] categories = {"Personnel Records", "Mission Briefings", "Intelligence Reports"};
        
        String category = (String) JOptionPane.showInputDialog(
            this, "⚠️ WARNING: All access is monitored and logged.\n\nSelect Category:",
            "Access Classified Data", JOptionPane.WARNING_MESSAGE, null, categories, categories[0]
        );
        
        if (category != null) {
            String content = "╔═════════════════════════════════════╗\n" +
                           "    CLASSIFIED INFORMATION\n" +
                           "  AUTHORIZED PERSONNEL ONLY\n" +
                           "╚═════════════════════════════════════╝\n\n" +
                           "Category: " + category + "\n" +
                           "Access Level: " + user.getRole() + "\n" +
                           "Time: " + getCurrentTime() + "\n\n" +
                           "[REDACTED CONTENT - Access Logged]\n\n" +
                           "⚠️  All access is monitored.";
            
            showInformationDialog("CLASSIFIED - " + category, content);
            
            AuditLogger.logActivity(user.getUserId(), user.getUsername(),
                "ACCESSED_CLASSIFIED", category, "127.0.0.1", true);
        }
    }
    
    private void executeMission() {
        String[] missions = {
            "Operation Nightfall - Secure Sector 7",
            "Operation Stronghold - Fortify Base Alpha",
            "Operation Recon-7 - Intelligence Gathering"
        };
        
        String mission = (String) JOptionPane.showInputDialog(
            this, "⚠️ CRITICAL: Mission execution is irreversible.\n\nSelect Mission:",
            "Mission Execution", JOptionPane.WARNING_MESSAGE, null, missions, missions[0]
        );
        
        if (mission != null) {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Final Confirmation Required\n\n" +
                "Mission: " + mission + "\n" +
                "Authorized By: " + user.getUsername() + "\n\n" +
                "Proceed?", "CONFIRM", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            
            if (confirm == JOptionPane.YES_OPTION) {
                showProgressDialog("Mission Execution", "Deploying units...", () -> {
                    AuditLogger.logActivity(user.getUserId(), user.getUsername(),
                        "MISSION_EXECUTED", mission, "127.0.0.1", true);
                    
                    UIHelper.showInfoDialog(this,
                        "✓ Mission Execution Confirmed\n\n" +
                        "Units deployed successfully.", "Success");
                });
            }
        }
    }
    
    // ============ UTILITY METHODS ============
    
    private void showInformationDialog(String title, String content) {
        JTextArea area = UIHelper.createStyledTextArea();
        area.setText(content);
        area.setEditable(false);
        
        JScrollPane pane = new JScrollPane(area);
        pane.setPreferredSize(new Dimension(600, 400));
        
        JOptionPane.showMessageDialog(this, pane, title, JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showProgressDialog(String title, String message, Runnable onComplete) {
        JProgressBar progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        progressBar.setValue(0);
        
        JDialog dialog = new JDialog(this, title, true);
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.add(new JLabel(message), BorderLayout.NORTH);
        panel.add(progressBar, BorderLayout.CENTER);
        dialog.add(panel);
        dialog.setSize(400, 130);
        dialog.setLocationRelativeTo(this);
        
        Timer timer = new Timer(40, null);
        timer.addActionListener(e -> {
            int value = progressBar.getValue() + 2;
            progressBar.setValue(value);
            if (value >= 100) {
                timer.stop();
                dialog.dispose();
                if (onComplete != null) onComplete.run();
            }
        });
        
        timer.start();
        dialog.setVisible(true);
    }
    
    private void updateActivity() {
        SessionMonitor.updateActivity(sessionId);
    }
    
    private void handleLogout() {
        if (UIHelper.showConfirmDialog(this, "Are you sure you want to logout?", "Confirm Logout")) {
            SessionMonitor.endSession(sessionId);
            user.setLoggedIn(false);
            
            AuditLogger.logActivity(user.getUserId(), user.getUsername(),
                "LOGOUT", "User logged out", "127.0.0.1", true);
            
            UIHelper.showInfoDialog(this, "Logged out successfully.", "Goodbye");
            
            if (updateTimer != null) {
                updateTimer.stop();
            }
            
            new LoginFrame().setVisible(true);
            dispose();
        }
    }
    
    private void startLiveUpdates() {
        updateTimer = new Timer(1000, evt -> {
            timeLabel.setText(getCurrentTime());
            sessionStatusLabel.setText("Active - " + formatUptime());
        });
        updateTimer.start();
    }
    
    private String getCurrentTime() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    }
    
    private String formatUptime() {
        return "00:05:32";
    }
}