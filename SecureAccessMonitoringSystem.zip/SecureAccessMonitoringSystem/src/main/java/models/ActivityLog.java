/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author malai
 */

import java.time.LocalDateTime;

public class ActivityLog {
    private int logId;
    private int userId;
    private String username;
    private String action;
    private String details;
    private LocalDateTime timestamp;
    private String ipAddress;
    private boolean successful;
    
    // Constructor for new log
    public ActivityLog(int userId, String username, String action, String details, 
                      String ipAddress, boolean successful) {
        this.userId = userId;
        this.username = username;
        this.action = action;
        this.details = details;
        this.timestamp = LocalDateTime.now();
        this.ipAddress = ipAddress;
        this.successful = successful;
    }
    
    // Constructor for loading from database
    public ActivityLog(int logId, int userId, String username, String action, 
                      String details, LocalDateTime timestamp, String ipAddress, boolean successful) {
        this.logId = logId;
        this.userId = userId;
        this.username = username;
        this.action = action;
        this.details = details;
        this.timestamp = timestamp;
        this.ipAddress = ipAddress;
        this.successful = successful;
    }
    
    // Getters
    public int getLogId() { return logId; }
    public int getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getAction() { return action; }
    public String getDetails() { return details; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public String getIpAddress() { return ipAddress; }
    public boolean isSuccessful() { return successful; }
    
    // Setters
    public void setLogId(int logId) { this.logId = logId; }
    
    @Override
    public String toString() {
        return String.format("[%s] %s - %s: %s (%s)", 
            timestamp, username, action, details, successful ? "SUCCESS" : "FAILED");
    }
}
