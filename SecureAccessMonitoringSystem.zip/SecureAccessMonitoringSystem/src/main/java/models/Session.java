/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author malai
 */

import java.time.LocalDateTime;
import java.util.UUID;

public class Session {
    private String sessionId;
    private int userId;
    private LocalDateTime loginTime;
    private LocalDateTime logoutTime;
    private LocalDateTime lastActivityTime;
    private String ipAddress;
    private boolean isActive;
    
    // Constructor for new session
    public Session(int userId, String ipAddress) {
        this.sessionId = UUID.randomUUID().toString();
        this.userId = userId;
        this.loginTime = LocalDateTime.now();
        this.lastActivityTime = LocalDateTime.now();
        this.ipAddress = ipAddress;
        this.isActive = true;
    }
    
    // Constructor for loading from database
    public Session(String sessionId, int userId, LocalDateTime loginTime, 
                   LocalDateTime logoutTime, String ipAddress, boolean isActive) {
        this.sessionId = sessionId;
        this.userId = userId;
        this.loginTime = loginTime;
        this.logoutTime = logoutTime;
        this.lastActivityTime = loginTime;
        this.ipAddress = ipAddress;
        this.isActive = isActive;
    }
    
    public void updateActivity() {
        this.lastActivityTime = LocalDateTime.now();
    }
    
    public void terminate() {
        this.isActive = false;
        this.logoutTime = LocalDateTime.now();
    }
    
    public boolean isExpired(long timeoutMillis) {
        if (lastActivityTime == null) return true;
        long diff = java.time.Duration.between(lastActivityTime, LocalDateTime.now()).toMillis();
        return diff > timeoutMillis;
    }
    
    // Getters
    public String getSessionId() { return sessionId; }
    public int getUserId() { return userId; }
    public LocalDateTime getLoginTime() { return loginTime; }
    public LocalDateTime getLogoutTime() { return logoutTime; }
    public LocalDateTime getLastActivityTime() { return lastActivityTime; }
    public String getIpAddress() { return ipAddress; }
    public boolean isActive() { return isActive; }
    
    // Setters
    public void setActive(boolean active) { this.isActive = active; }
    public void setLogoutTime(LocalDateTime logoutTime) { this.logoutTime = logoutTime; }
    
    @Override
    public String toString() {
        return String.format("Session{id='%s', userId=%d, loginTime=%s, active=%s}", 
            sessionId, userId, loginTime, isActive);
    }
}