/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author malai
 */

import at.favre.lib.crypto.bcrypt.BCrypt;

public class User {
    private int userId;
    private String username;
    private String passwordHash;
    private String role;
    private String rank;
    private boolean isLoggedIn;
    private long lastActivityTime;
    private String sessionId;
    private boolean isActive;
    
    // Constructor for creating new user
    public User(String username, String password, String role, String rank) {
        this.username = username;
        // ✅ CORRECT SYNTAX for at.favre.lib
        this.passwordHash = BCrypt.withDefaults().hashToString(12, password.toCharArray());
        this.role = role;
        this.rank = rank;
        this.isLoggedIn = false;
        this.lastActivityTime = System.currentTimeMillis();
        this.isActive = true;
    }
    
    // Constructor for loading from database
    public User(int userId, String username, String passwordHash, String role, String rank, boolean isActive) {
        this.userId = userId;
        this.username = username;
        this.passwordHash = passwordHash;
        this.role = role;
        this.rank = rank;
        this.isLoggedIn = false;
        this.lastActivityTime = System.currentTimeMillis();
        this.isActive = isActive;
    }
    
    // ✅ CORRECT Authenticate password method
    public boolean authenticate(String password) {
        BCrypt.Result result = BCrypt.verifyer().verify(password.toCharArray(), this.passwordHash);
        return result.verified;
    }
    
    // Check if session expired (15 minutes)
    public boolean isSessionExpired(long timeoutMillis) {
        return (System.currentTimeMillis() - lastActivityTime) > timeoutMillis;
    }
    
    // Update activity timestamp
    public void updateActivity() {
        this.lastActivityTime = System.currentTimeMillis();
    }
    
    // Getters
    public int getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getPasswordHash() { return passwordHash; }
    public String getRole() { return role; }
    public String getRank() { return rank; }
    public boolean isLoggedIn() { return isLoggedIn; }
    public long getLastActivityTime() { return lastActivityTime; }
    public String getSessionId() { return sessionId; }
    public boolean isActive() { return isActive; }
    
    // Setters
    public void setUserId(int userId) { this.userId = userId; }
    public void setLoggedIn(boolean loggedIn) { this.isLoggedIn = loggedIn; }
    public void setSessionId(String sessionId) { this.sessionId = sessionId; }
    public void setActive(boolean active) { this.isActive = active; }
    public void setRole(String role) { this.role = role; }
    public void setRank(String rank) { this.rank = rank; }
    
    @Override
    public String toString() {
        return String.format("User{id=%d, username='%s', role='%s', rank='%s'}", 
            userId, username, role, rank);
    }
}