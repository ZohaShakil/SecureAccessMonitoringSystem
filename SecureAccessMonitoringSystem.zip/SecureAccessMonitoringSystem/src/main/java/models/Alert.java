/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author malai
 */

import java.time.LocalDateTime;

public class Alert {
    public enum Severity { LOW, MEDIUM, HIGH, CRITICAL }
    
    private int alertId;
    private Severity severity;
    private String message;
    private String details;
    private Integer userId;
    private String username;
    private LocalDateTime timestamp;
    private boolean acknowledged;
    
    // Constructor for new alert
    public Alert(Severity severity, String message, String details, Integer userId, String username) {
        this.severity = severity;
        this.message = message;
        this.details = details;
        this.userId = userId;
        this.username = username;
        this.timestamp = LocalDateTime.now();
        this.acknowledged = false;
    }
    
    // Constructor for loading from database
    public Alert(int alertId, Severity severity, String message, String details, 
                Integer userId, String username, LocalDateTime timestamp, boolean acknowledged) {
        this.alertId = alertId;
        this.severity = severity;
        this.message = message;
        this.details = details;
        this.userId = userId;
        this.username = username;
        this.timestamp = timestamp;
        this.acknowledged = acknowledged;
    }
    
    public void acknowledge() {
        this.acknowledged = true;
    }
    
    // Getters
    public int getAlertId() { return alertId; }
    public Severity getSeverity() { return severity; }
    public String getMessage() { return message; }
    public String getDetails() { return details; }
    public Integer getUserId() { return userId; }
    public String getUsername() { return username; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public boolean isAcknowledged() { return acknowledged; }
    
    // Setters
    public void setAlertId(int alertId) { this.alertId = alertId; }
    public void setAcknowledged(boolean acknowledged) { this.acknowledged = acknowledged; }
    
    @Override
    public String toString() {
        return String.format("[%s] %s - %s: %s", 
            severity, timestamp, username != null ? username : "SYSTEM", message);
    }
}
