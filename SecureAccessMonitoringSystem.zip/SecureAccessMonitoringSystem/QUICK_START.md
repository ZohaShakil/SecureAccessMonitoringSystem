# 🚀 QUICK START GUIDE

## Method 1: Using Run Scripts (EASIEST!)

### Windows:
1. Extract the `SecureAccessMonitoringSystem_Fixed.zip`
2. Copy `run_windows.bat` into the `SecureAccessMonitoringSystem` folder
3. Double-click `run_windows.bat`
4. Wait for the application to launch

### Linux/Mac:
1. Extract the `SecureAccessMonitoringSystem_Fixed.zip`
2. Copy `run_unix.sh` into the `SecureAccessMonitoringSystem` folder
3. Open terminal in that folder
4. Run: `./run_unix.sh`
5. Wait for the application to launch

---

## Method 2: Manual Command Line

### Step 1: Open Terminal/Command Prompt
Navigate to project folder:
```bash
cd SecureAccessMonitoringSystem
```

### Step 2: Run with Maven
```bash
mvn clean compile
mvn exec:java -Dexec.mainClass="Main"
```

---

## 🔑 Login Credentials

Once the application launches, use these credentials:

**Admin Account:**
- Username: `admin`
- Password: `admin123`

**Other Accounts:**
- Username: `commander1` / Password: `pass123`
- Username: `officer1` / Password: `pass123`
- Username: `soldier1` / Password: `pass123`

---

## ✅ What You'll See

1. **Console Output:**
   - Database initialization
   - Default users creation
   - System ready message

2. **Login Window:**
   - Modern dark theme
   - "DEFENCE OPERATIONS" title
   - Username and password fields (NOW WITH VISIBLE TEXT!)
   - LOGIN button

3. **After Login:**
   - Dashboard with system statistics
   - Menu options based on your role
   - Real-time monitoring features

---

## ⚠️ Requirements

- Java JDK 17 or higher
- Apache Maven 3.6+
- Internet connection (first run only, to download dependencies)

---

## 🛠️ If Something Goes Wrong

**Issue:** Application won't start
- Make sure Java is installed: `java -version`
- Make sure Maven is installed: `mvn -version`

**Issue:** Can't see text in input fields
- This has been FIXED in the updated code!
- Make sure you're using the fixed version

**Issue:** Login fails
- Check console for error messages
- Verify you're using correct credentials
- Database might need reset (delete `sams.db`)

---

## 📁 Files You Need

1. `SecureAccessMonitoringSystem_Fixed.zip` - The fixed project
2. `run_windows.bat` - Windows run script
3. `run_unix.sh` - Linux/Mac run script
4. `RUN_PROJECT_INSTRUCTIONS.md` - Detailed instructions

---

## 🎯 Testing the Login Page

1. Launch the application
2. Type in the **Username** field - you should see the text clearly!
3. Type in the **Password** field - you should see dots/asterisks
4. The fields are now 480px wide × 48px tall (previously 450×42)
5. Try logging in with: `admin` / `admin123`

---

**That's it! Enjoy your secure monitoring system! 🛡️**
