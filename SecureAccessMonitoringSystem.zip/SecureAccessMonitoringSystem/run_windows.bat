@echo off
echo ========================================
echo  Defence Operations Monitoring System
echo  Starting Application...
echo ========================================
echo.

REM Check if Maven is installed
mvn -version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Maven is not installed or not in PATH
    echo Please install Maven from: https://maven.apache.org/download.cgi
    pause
    exit /b 1
)

REM Check if Java is installed
java -version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Java is not installed or not in PATH
    echo Please install JDK 17+ from: https://www.oracle.com/java/technologies/downloads/
    pause
    exit /b 1
)

echo Step 1: Cleaning and compiling project...
call mvn clean compile

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ERROR: Build failed! Check the error messages above.
    pause
    exit /b 1
)

echo.
echo Step 2: Running application...
echo.
call mvn exec:java -Dexec.mainClass="Main"

pause
